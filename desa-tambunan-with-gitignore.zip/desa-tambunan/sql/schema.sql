-- =========================================================
-- Skema Database Website Desa Tambunan
-- Import file ini via phpMyAdmin (cPanel) atau perintah:
--   mysql -u USERNAME -p NAMA_DATABASE < schema.sql
-- =========================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------
-- Tabel: admins
-- Hanya 1 admin (Pak Lurah) yang bisa login ke dashboard
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Akun default: username "admin" / password "GantiSegera123!"
-- WAJIB diganti setelah login pertama kali (lihat panduan di README).
-- Hash di bawah valid untuk password "GantiSegera123!" (dibuat dgn password_hash())
INSERT INTO admins (username, password_hash) VALUES
('admin', '$2y$10$GY.MabsMAr0.dEF3HIhhJ./Jq2JHP/WJfnOcPOdIxQrztBF62UAFS')
ON DUPLICATE KEY UPDATE username = username;

-- ---------------------------------------------------------
-- Tabel: village_stats
-- Satu baris saja (id selalu 1) berisi angka statistik desa
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS village_stats (
    id INT PRIMARY KEY DEFAULT 1,
    penduduk INT NOT NULL DEFAULT 0,
    kepala_keluarga INT NOT NULL DEFAULT 0,
    luas_wilayah DECIMAL(6,2) NOT NULL DEFAULT 0,
    jumlah_dusun INT NOT NULL DEFAULT 0,
    ketinggian INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO village_stats (id, penduduk, kepala_keluarga, luas_wilayah, jumlah_dusun, ketinggian) VALUES
(1, 2450, 612, 15.2, 8, 1200)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: lurah
-- Satu baris saja (id selalu 1) berisi data Lurah Tambunan
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS lurah (
    id INT PRIMARY KEY DEFAULT 1,
    nama VARCHAR(100) NOT NULL,
    no_hp VARCHAR(20) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lurah (id, nama, no_hp) VALUES
(1, 'Johanis Pabuka, SE', '081247412255')
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: lingkungan
-- Daftar Lingkungan beserta kepala lingkungannya
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS lingkungan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    kepala_nama VARCHAR(100) NOT NULL,
    kepala_hp VARCHAR(20) NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lingkungan (id, nama, kepala_nama, kepala_hp, urutan) VALUES
(1, 'Lingkungan Buntu Batakan', 'Yorinda Rante Manikallo', '081355123888', 1),
(2, 'Lingkungan Garampa\'', 'Andarias Patinaran', '085343890282', 2),
(3, 'Lingkungan Mandetek', 'Daniel Isak Lopulalan', '085256402854', 3),
(4, 'Lingkungan Rante To\'long', 'Yohanis Sula\'', '081343696325', 4);

-- ---------------------------------------------------------
-- Tabel: rt
-- Daftar RT di bawah setiap Lingkungan
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS rt (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lingkungan_id INT NOT NULL,
    nama VARCHAR(100) NOT NULL,
    ketua_nama VARCHAR(100) NOT NULL,
    ketua_hp VARCHAR(20) NOT NULL,
    urutan INT NOT NULL DEFAULT 0,
    FOREIGN KEY (lingkungan_id) REFERENCES lingkungan(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO rt (lingkungan_id, nama, ketua_nama, ketua_hp, urutan) VALUES
(1, 'Tetebassi', 'Yohanis Marjono', '082296493548', 1),
(1, 'Katangka', 'Simon Pappangkarua', '081343731038', 2),
(2, 'Garampa\'', 'Enos Paranta\'', '082189439447', 1),
(2, 'Lando Tengnge\'', 'Paulus Tato Pasampe', '082158863962', 2),
(3, 'Mendoe Selatan', 'Lukas Bara\' Padang', '081355104420', 1),
(3, 'Mendoe Utara', 'Andarias Rambak', '081342329219', 2),
(3, 'Sipate', 'Dina Sarce Kala\'Padang', '082399722481', 3),
(4, 'To\'long', 'Semuel Sulle', '085255278757', 1),
(4, 'Tammu-Tammu', 'Agustinus Sanda', '082193686698', 2);
