-- =========================================================
-- Migration Tambahan: Fasilitas Umum, Artikel & Legal Corner
-- Aman diimport ke database yang sudah ada isinya.
-- =========================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------
-- Tabel: fasilitas_umum
-- Daftar fasilitas umum di wilayah Kelurahan + link Google Maps
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS fasilitas_umum (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    gmaps_link VARCHAR(500) NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO fasilitas_umum (id, nama, gmaps_link, urutan) VALUES
(1, 'Kantor Kelurahan Tambunan', 'https://www.google.com/maps/place/?q=place_id:ChIJDXi2JD3tky0RhbVn0MlTwOk', 1),
(2, 'Rumah Sakit Umum Lakipadada', 'https://www.google.com/maps/place/?q=place_id:ChIJgxeX9Y_tky0R2hCHliUyLk8', 2),
(3, 'Posyandu Garampa', 'https://www.google.com/maps/place/?q=place_id:ChIJPTHwBwDtky0RBicaOhJwFGk', 3),
(4, 'Credit Union Sauan Sibarrung', 'https://www.google.com/maps/place/?q=place_id:ChIJsXCFac3tky0R7-A5rZDDIWs', 4),
(5, 'Indomaret Lakipadada', 'https://www.google.com/maps/place/?q=place_id:ChIJvVIHrObtky0RV-XysPEnhx4', 5),
(6, 'GPdI Bukit Hermon Mandetek', 'https://www.google.com/maps/place/?q=place_id:ChIJPwNf0DPsky0R6TZSkpeMpf8', 6),
(7, 'Gereja Toraja Rante To\'long Mandetek', NULL, 7),
(8, 'Gereja Toraja Getsemani Sipate', NULL, 8),
(9, 'GPT Jemaat Kristus Ajaib Mandetek', 'https://www.google.com/maps/place/?q=place_id:ChIJc5OOlUntky0RyAWpBxGXjgc', 9),
(10, 'Gereja Kemah Injil Mandetek', NULL, 10),
(11, 'Gereja Toraja Imanuel Mandetek', 'https://www.google.com/maps/place/?q=place_id:ChIJS2ZAJ8ztky0RPw3MeZbaXco', 11),
(12, 'Potensi Wisata Lo\'ko Dewata', NULL, 12),
(13, 'SPBU Tetebassi', 'https://www.google.com/maps/place/?q=place_id:ChIJybDUH8ztky0Rp-4GJtL8vhI', 13),
(14, 'PDAM Mandetek', 'https://www.google.com/maps/place/?q=place_id:ChIJfSYYEpPtky0RJ4WidYc6Xx4', 14),
(15, 'Hotel Metro Permai', 'https://www.google.com/maps/place/?q=place_id:ChIJb07GdJntky0RSKCOwA_FobY', 15),
(16, 'TK Astrini', 'https://www.google.com/maps/place/?q=place_id:ChIJhWFZ5Eztky0RCqL4CnIEe8M', 16),
(17, 'SDN 4 Bungin', 'https://www.google.com/maps/place/?q=place_id:ChIJ-y_yQy7sky0Rv5vbOc5u7Bc', 17),
(18, 'SDN 8 Makale Utara', 'https://www.google.com/maps/place/?q=place_id:ChIJH0vKpl3tky0R286QWsalQqc', 18),
(19, 'SMAK Mandetek', NULL, 19),
(20, 'SMKS Kesehatan Astrini', NULL, 20),
(21, 'Pura Tambunan Litak', 'https://www.google.com/maps/place/?q=place_id:ChIJlSVz_2rtky0R_Ov3v0DDX7o', 21),
(22, 'Gereja Katolik Mandetek', 'https://www.google.com/maps/place/?q=place_id:ChIJH03Cbc7tky0Rw0bNN23XZ7E', 22),
(23, 'GBT Bukit Sion Mandetek', 'https://www.google.com/maps/place/?q=place_id:ChIJr27lltTtky0RsTkJK-iuVPY', 23)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: artikel
-- Tulisan panjang/mendalam tentang Kelurahan (beda dari berita)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS artikel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    ringkasan VARCHAR(300) NOT NULL,
    konten LONGTEXT NOT NULL,
    penulis VARCHAR(100) NOT NULL DEFAULT 'Admin',
    image_path VARCHAR(500) NOT NULL,
    tanggal DATE NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO artikel (id, judul, ringkasan, konten, penulis, image_path, tanggal, urutan) VALUES
(1, 'Menelusuri Jejak Sejarah Kelurahan Tambunan', 'Perjalanan panjang Tambunan dari sebuah perkampungan kecil hingga menjadi kelurahan yang dikenal akan kekayaan budaya Torajanya.', 'Kelurahan Tambunan memiliki sejarah panjang yang berakar dari tradisi leluhur Toraja. Sejak awal berdirinya, wilayah ini menjadi tempat bermukim beberapa rumpun keluarga besar yang membangun kehidupan bergotong royong.\n\nSeiring waktu, Tambunan berkembang menjadi pusat kegiatan masyarakat dengan berbagai fasilitas umum, sambil tetap menjaga adat istiadat yang diwariskan turun-temurun. Rumah Tongkonan yang berdiri kokoh hingga kini menjadi saksi bisu perjalanan panjang tersebut.\n\nHingga hari ini, warga Tambunan terus berupaya melestarikan warisan budaya sembari membuka diri terhadap perkembangan zaman, menjadikan kelurahan ini sebagai contoh harmoni antara tradisi dan kemajuan.', 'Admin', 'https://lh3.googleusercontent.com/aida-public/AB6AXuBMOjv0IfwF5C2kz2Rs9Q6mnbU_9mAOmaL2sGGOajBDdq7eAgNI9VIzC8KpwL0MuY8PIJLHLyi6VQsyfZwpsxUfiP5fvTpbCobbUeBtRX0zVF0JqTRNx_LktjxdpyuvdWVMYTCpkfKskcGmnbI_xsoUPPJG_K7Y2U4K5sT3mMon-VkvCyNKytPOA_hI1RZoTzFkub4HUTKYEVfSc9c5qYWySRnTXz4n1ZD_t0x27pH_P304VTC64Md0TzR7E1j7DM6FP-3flLoiEx72', '2024-11-01', 1)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: legal_informasi
-- Sub-halaman "Informasi Hukum"
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS legal_informasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    isi TEXT NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO legal_informasi (id, judul, isi, urutan) VALUES
(1, 'Hak dan Kewajiban Wisatawan', 'Setiap wisatawan yang berkunjung wajib mematuhi adat istiadat setempat, menjaga kebersihan lingkungan, dan menghormati privasi warga saat berada di area permukiman maupun situs budaya.', 1),
(2, 'Aturan Dasar Usaha Pariwisata', 'Pelaku usaha wisata (homestay, pemandu, kuliner) disarankan memiliki izin usaha mikro dan terdaftar di kantor Kelurahan agar mendapat pembinaan dan perlindungan hukum.', 2)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: legal_faq (Tanya Hukum)
-- status: pending (baru masuk) / dijawab (sudah ditindaklanjuti admin)
-- jawaban & tampil_publik dipakai untuk daftar FAQ publik
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS legal_faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    pertanyaan TEXT NOT NULL,
    jawaban TEXT NULL,
    status ENUM('pending', 'dijawab') NOT NULL DEFAULT 'pending',
    tampil_publik TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------
-- Tabel: legal_layanan (Rujukan Layanan)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS legal_layanan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_instansi VARCHAR(150) NOT NULL,
    deskripsi VARCHAR(300) NOT NULL,
    kontak VARCHAR(100) NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO legal_layanan (id, nama_instansi, deskripsi, kontak, urutan) VALUES
(1, 'Pos Bantuan Hukum (Posbakum) Tana Toraja', 'Layanan konsultasi hukum gratis bagi masyarakat tidak mampu.', '(0423) 21XXX', 1),
(2, 'Polsek Makale Utara', 'Layanan keamanan dan pelaporan tindak pidana.', '110 / (0423) 22XXX', 2)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: legal_buku (Unduh Buku Saku - file PDF)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS legal_buku (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    deskripsi VARCHAR(300) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------
-- Tabel: legal_darurat (Kontak Darurat)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS legal_darurat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    nomor VARCHAR(30) NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO legal_darurat (id, nama, nomor, urutan) VALUES
(1, 'Polisi', '110', 1),
(2, 'Ambulans', '119', 2),
(3, 'Pemadam Kebakaran', '113', 3),
(4, 'Kantor Kelurahan Tambunan', '081247412255', 4)
ON DUPLICATE KEY UPDATE id = id;
