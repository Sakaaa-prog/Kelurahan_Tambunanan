-- =========================================================
-- Migration Tambahan: Hero, Potensi Desa, Galeri
-- File ini AMAN diimport ke database yang sudah ada isinya
-- (tidak akan menghapus/reset data statistik & struktur yang
-- sudah kamu ubah sebelumnya, karena cuma bikin tabel BARU).
--
-- Cara import: sama seperti schema.sql
-- phpMyAdmin -> pilih database desatambunan -> tab Impor ->
-- pilih file ini -> Go
-- =========================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------
-- Tabel: berita
-- Artikel/berita di section "Berita Terbaru"
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS berita (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kategori VARCHAR(50) NOT NULL,
    judul VARCHAR(150) NOT NULL,
    deskripsi TEXT NOT NULL,
    image_path VARCHAR(500) NOT NULL,
    tanggal DATE NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO berita (id, kategori, judul, deskripsi, image_path, tanggal, urutan) VALUES
(1, 'Pembangunan', 'Musyawarah Perencanaan Desa 2025', 'Membahas arah kebijakan strategis dalam pengalokasian dana desa untuk sektor pariwisata dan infrastruktur dasar.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuDJhpU4t_M21kEVUMAL_kFE8i92bQNTw5ypA_jC0z5JND1cjq7f2HQvTb6kT6lpuM190Lxp7nPLQJEB5Tm9z37zAY_h8kId-z-5kODO7WyKHPrl2-8kFShGXgFX6Ot4N19nYkrb15TKcUOTOEGKDjPr7JC93rmLuQtOBh3pu_f7ghLNb9sxm7K2IVLcslULlKFOBn4mzHK6a466dnSLdC97InXvL1IaOWajdW66jowpx2FaPueK4ybpO1v1azIssiw0_bjObMjxGFzW', '2024-10-12', 1),
(2, 'Budaya', 'Festival Budaya Tambunan Kembali Digelar', 'Kemeriahan perayaan syukur pasca panen yang melibatkan seluruh warga desa dan menarik wisatawan mancanegara.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuBBuk6G1csmvp8RMbaWfJkUVh3gMdYtsOSoJ32CDlaGuVlr2sJhhjvXo-L_4B-suIjtgyEcpAA_6d04suXoaZvoIBI-7SKbIwwYUQYTlznyuH_OVb2M4duJrlGKXkGZOx1Jktr2eI5l1o81oFkcLDL53YEoTuO0blSGUQOwO1V_i6iWRgzss8RnuiH4udHF4nzpE1USPYa4KCh4Uip35ZZAKXytBBIPrrtiX_F6HafZtfFdCjMwOLIzi7XS3YmbimbUjgke1CGnQOcW', '2024-10-05', 2),
(3, 'Pemberdayaan', 'Program Digitalisasi UMKM Desa', 'Pelatihan intensif bagi pelaku usaha lokal dalam memanfaatkan platform e-commerce untuk memasarkan produk tenun.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuBlv2uIb5Ot-yMi-MvofYxRL5Xvn84l8ixfUy68nSvKUxNro8IkX0BoG7tVDIrRpAL8htHrpsLDlVsZEiWVpk9sMMlm_F0McrInQOY_Sg85iL1ao0kvQ0uFxuIyBXB1KAedrPXXHshCzKghuar2sYl0BXyk9soVPcUzwGZPqE0rWB1nRbfdmeCPakHEf1IGb46eNfpaHFLKM-KwDrct8mTaDaL9l9jewlASiuIElOTo2rsSCAWeRq-sL8qb32M81OmQdfERoqcbTvi1', '2024-09-28', 3)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: berita
-- Artikel di section "Berita Terbaru"
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS berita (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(150) NOT NULL,
    kategori VARCHAR(50) NOT NULL,
    deskripsi TEXT NOT NULL,
    image_path VARCHAR(500) NOT NULL,
    tanggal DATE NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO berita (id, judul, kategori, deskripsi, image_path, tanggal, urutan) VALUES
(1, 'Musyawarah Perencanaan Desa 2025', 'Pembangunan', 'Membahas arah kebijakan strategis dalam pengalokasian dana desa untuk sektor pariwisata dan infrastruktur dasar.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuDJhpU4t_M21kEVUMAL_kFE8i92bQNTw5ypA_jC0z5JND1cjq7f2HQvTb6kT6lpuM190Lxp7nPLQJEB5Tm9z37zAY_h8kId-z-5kODO7WyKHPrl2-8kFShGXgFX6Ot4N19nYkrb15TKcUOTOEGKDjPr7JC93rmLuQtOBh3pu_f7ghLNb9sxm7K2IVLcslULlKFOBn4mzHK6a466dnSLdC97InXvL1IaOWajdW66jowpx2FaPueK4ybpO1v1azIssiw0_bjObMjxGFzW', '2024-10-12', 1),
(2, 'Festival Budaya Tambunan Kembali Digelar', 'Budaya', 'Kemeriahan perayaan syukur pasca panen yang melibatkan seluruh warga desa dan menarik wisatawan mancanegara.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuBBuk6G1csmvp8RMbaWfJkUVh3gMdYtsOSoJ32CDlaGuVlr2sJhhjvXo-L_4B-suIjtgyEcpAA_6d04suXoaZvoIBI-7SKbIwwYUQYTlznyuH_OVb2M4duJrlGKXkGZOx1Jktr2eI5l1o81oFkcLDL53YEoTuO0blSGUQOwO1V_i6iWRgzss8RnuiH4udHF4nzpE1USPYa4KCh4Uip35ZZAKXytBBIPrrtiX_F6HafZtfFdCjMwOLIzi7XS3YmbimbUjgke1CGnQOcW', '2024-10-05', 2),
(3, 'Program Digitalisasi UMKM Desa', 'Pemberdayaan', 'Pelatihan intensif bagi pelaku usaha lokal dalam memanfaatkan platform e-commerce untuk memasarkan produk tenun.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuBlv2uIb5Ot-yMi-MvofYxRL5Xvn84l8ixfUy68nSvKUxNro8IkX0BoG7tVDIrRpAL8htHrpsLDlVsZEiWVpk9sMMlm_F0McrInQOY_Sg85iL1ao0kvQ0uFxuIyBXB1KAedrPXXHshCzKghuar2sYl0BXyk9soVPcUzwGZPqE0rWB1nRbfdmeCPakHEf1IGb46eNfpaHFLKM-KwDrct8mTaDaL9l9jewlASiuIElOTo2rsSCAWeRq-sL8qb32M81OmQdfERoqcbTvi1', '2024-09-28', 3)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: profil
-- Satu baris saja (id selalu 1) untuk foto di section "Profil Desa"
-- (foto pengrajin + badge "Established History")
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS profil (
    id INT PRIMARY KEY DEFAULT 1,
    image_path VARCHAR(500) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO profil (id, image_path) VALUES
(1, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBVgUM9WtmRnipfEvZlsuHfp-f9yhhI4jt52fMb0EE1mfl0Vu6F2HW0IZhlWCKgGFe5BZN63SegGUQSuQ3POJXd866W8oNXRR8oIP-8qwAVbWUifN1AjlKtgIYpXtu_X8odZVEYirHLnNw5uMe9tIWHjRs-HUHfs69GfE4ygS8jfOk6e7L3EGIT-sJjzm5kezn_uJr_pbHewYR7eKoRUsaJDAH7bDK_tXFV2iYBJwP5iR-cShffL0cUL8fbcvMPmgGruSdaOmamEOOc')
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: hero
-- Satu baris saja (id selalu 1) untuk foto hero (halaman awal)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS hero (
    id INT PRIMARY KEY DEFAULT 1,
    image_path VARCHAR(500) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO hero (id, image_path) VALUES
(1, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBMOjv0IfwF5C2kz2Rs9Q6mnbU_9mAOmaL2sGGOajBDdq7eAgNI9VIzC8KpwL0MuY8PIJLHLyi6VQsyfZwpsxUfiP5fvTpbCobbUeBtRX0zVF0JqTRNx_LktjxdpyuvdWVMYTCpkfKskcGmnbI_xsoUPPJG_K7Y2U4K5sT3mMon-VkvCyNKytPOA_hI1RZoTzFkub4HUTKYEVfSc9c5qYWySRnTXz4n1ZD_t0x27pH_P304VTC64Md0TzR7E1j7DM6FP-3flLoiEx72')
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: potensi
-- Kartu-kartu di section "Potensi Desa" (foto + judul + deskripsi)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS potensi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(100) NOT NULL,
    deskripsi TEXT NOT NULL,
    image_path VARCHAR(500) NOT NULL,
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO potensi (id, judul, deskripsi, image_path, urutan) VALUES
(1, 'Potensi Alam', 'Keindahan lanskap pegunungan dan sumber mata air alami yang terjaga kelestariannya.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuAQEg407Klw3Z3R1nDFJp9b_CsOvgrmm6JMkgVCVhTOAT-QbI7VSO6xcATRGtri2dDn-dDfQQeeUXJ62L-h9aWrl2LJOrTV62kuBicCyKUM-X-RHND4jm_e7VePmJ_cnc76INXUSkOGZNypN2bQD2WNeWmnfKSulqZnZwIZKWPnGfDDiOeTyK4Cv_hf4ZBGNbEtgg70M3BQSkeDX9NacHM-pRiClVZA2MVkAUtatiOpVpJWJH0ho7KgOe39hqmhe6h0NY-PnLnBuKn_', 1),
(2, 'Warisan Budaya', 'Arsitektur Tongkonan yang megah dan tradisi luhur yang terus diwariskan antar generasi.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuCUHqqp6B4YjN2S5Z6tlBgNcnM1N3wtPoGfJY_jSarR0haB6QSJgiB3TatLgCJqy5u-fMTThVIWpoFJZkt2L4E1jamrfOrXYEVGm3Bo4O3qxV9KARo07fci0nARJuVTzzzUoxY7vlwC_VJT3Kfk2zrUW0AgZHkzMP0sTS8mbI2mlCy27v8RMGsXdSjQRrvqp0kRwDZ3Fvu8AMoPR-hj8S8Ow4YLlHQRv8AQYAhZxOd3d-dyK3aqpdCtGrNiYMP927L7CP-CVNXNOtHa', 2),
(3, 'UMKM Lokal', 'Produk kerajinan tangan dan industri kreatif masyarakat yang mendukung ekonomi desa.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuCWxl-C0zqg-q8jMC2tgfz9PXcmL0XRMuBabT22RqfQTCLjTTZkOZPJsPnQ_rtuy5uwyRbYUnOK9tdfAObH0iskMbS7dpOJO37Vi-tQsUjCpRfPBLMmgoNCi8bNfm6YCNGT1lq0BeZaWFtg9Wg6h1WIR7o9BWTr_dCXJ2W0MNnXXoNvOlTYu6VnHulqcTXlLM4OpE3z8xn8uT1U2DIYMe8jeGlyMLtzWWHa7hRJYnVGQD1Wk3rdRCbaene_wF9KlwlQ8O2KGiizmxmE', 3),
(4, 'Hasil Bumi', 'Kopi Toraja berkualitas premium dan hasil pertanian organik dari tanah subur Tambunan.', 'https://lh3.googleusercontent.com/aida-public/AB6AXuCBBW4M1-7xcIJdlSO8BCBd5_JPavMTyjXqGn44hlBZFHVleM38fkrwXY272u6mmQPJ9W0HCiKs9HRWwB-3HnBIkgGFLD5EDqj98g5rb96D_Wcn6PlP69j_dPr8ueZi5tO4HbgwQrOAaY_zt5NeqoBU2_3rWQ6XpdEtsjpXvVwLp8Dc04XhNvgGS74hUNNbV2V-EWtHS0jlu80fXn6HJ2-AvEWxoYQEOE8QZQARFVQLtSbIR7GuAtyN33bjaIcqUI3Jg4Ea49PoIPqQ', 4)
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------
-- Tabel: galeri
-- Foto-foto di section "Jendela Desa" (masonry grid)
-- layout: normal / tall / wide (menentukan ukuran kotak foto)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS galeri (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_path VARCHAR(500) NOT NULL,
    alt_text VARCHAR(255) NOT NULL DEFAULT '',
    layout ENUM('normal', 'tall', 'wide') NOT NULL DEFAULT 'normal',
    urutan INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO galeri (id, image_path, alt_text, layout, urutan) VALUES
(1, 'https://lh3.googleusercontent.com/aida-public/AB6AXuCy0VWq_36siHKJrXOb4CzC6BkIGOWabRI-S3yLiodzogNk1wcy9iDhhEmX3UA18M0QcrWz4ZQxsmaT22hGhDnh1cbOgI3g9eAKKHopq8GEL2yDiW15Ep80b3mX3y9evMr63GBwnTcdS21OpocGCS9uq6-Y0b-uNWY-UTNsbQHWNdQ7R2GLbe3GssTFmK6vTYaCTl1w3uNpu__b1wljtRG1YMGSgGHSMbfeJhWpsC1bVGgjoAOv9AatZdhAVSadv5B-ThsEyqYNNypo', 'Tongkonan menjulang di antara kabut pegunungan', 'tall', 1),
(2, 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_zM1hH7lEcRN0vTqLJ1cC9ib8MIV_bVW18OK7nw1LQPKtTcDVOTVYqLVzeZxhs1bQRYpH1X0kFFswq-jiwWKOUPneCUia6_zYj6n3hFFRWJZ9cD41pjDZuxpiP9smdeImJpsY4n1lMSdq193Vx5ug8tSfGVb4TEcPlVnrs56bdIghU_an2IDfFBd6dt4NX-xlRw5Rj8WZKvqKKZ8cGcqioZSNc_LERysBZDOlQB0LBiYK_UI12PRT0D04nM8rl-ap2_iJt07mRmk6', 'Butir padi hijau di pagi hari', 'normal', 2),
(3, 'https://lh3.googleusercontent.com/aida-public/AB6AXuDjsUmzP5tmnRWZUZBMfhROtNE0LN8oBRncEmqIxWRRSiPIrTBfNeup0aeD31t83A5tXjC9rpzJlz4L-rLbZICFYCRTwZJFaHbEB88HxxyhWlHYv4aO2IJh4SfOeJWI9MbzrHLWeRRdX6ZIzI2gv9vHgdy7JacGipKt0fEPaXnScXwOkTafBU7IAY7yJ4bo9CC3JzJEtcBoQTm-NBWVFBbr2YjB0jfsePsLDgXHV9t243uVtmjFx1IptqI4fzFg0uexXv0IcJu091bs', 'Warga berkumpul dalam upacara adat', 'wide', 3),
(4, 'https://lh3.googleusercontent.com/aida-public/AB6AXuAfwBAkbAkKMM2kzHHNmEl2epwoOkLg-16JyvEr18TEAvxYT9V4E_f6yfFCLXiFq_S8i2tW-kP5nmcdI6-Rpruna81vEHWSlRK4E83itOIsLFWrrV_m_aygmuruRsCV_0JSthBS9a2648EJ3r98eBCd4MGN9H2wtPVMHlPDJHuIW9tfZ9bdIZrfcg8nXJrPMkicZ-ppvn0IX63Qgwe5oKFTWWH4qK5r299cwVXpOgKTMNax9FXqtfdKDqqsV_TXHh49XZz_LqRVBrdX', 'Anak desa tersenyum dengan kain tradisional', 'normal', 4),
(5, 'https://lh3.googleusercontent.com/aida-public/AB6AXuAzH48ys6yh2SD-hx4c0MKL7lzRDCo0bUJZoQyExIkX6XGRZ5AiTQ5abnVRaACla1F6PN7G4GZk6rysFB8n5mHVW5wWVm-wRAW8wTycoxiBk_cXn9WY70GxcohQcYUlwZ1or21wWmgO_Zk6GgVQCwIShHNv8cohgLWfJeu9wyMy5fGTOH4iazR7KUblEf4EbM5gyY-mUtg5Qp0UNQZKHJcz04UBO7EEDYmqonR6PcoQ76vIPCZmzxTOlQWu3bmt2OaUD1DPmzuXMQT-', 'Jalur hutan menuju air terjun tersembunyi', 'tall', 5),
(6, 'https://lh3.googleusercontent.com/aida-public/AB6AXuDzonWUEzujALOr6-GRyjaIBTwJU5eSMbSQQs8EWo4WT4L41oqgDl_78N1HtvWPsJuMmGcDmwM-fgtbu4QXIJaJJp06ohcS4snafoABCVawzofMGvQHKt8o_0bwq_jAJR6ytaXu1exblPSXs1jRlf9nOaFDyPwrZodqPyimDWaIJHrvp2IS5kCyxQnDCKoxYqCVPZYcvVsmAyiRYG49H5paTkg6UdgDLH55ZOQgX5UOa972hc-dEP2kwX7sk-iHlQMK9EnSr0-75Bz8', 'Bima sakti di atas atap Tongkonan', 'normal', 6)
ON DUPLICATE KEY UPDATE id = id;
