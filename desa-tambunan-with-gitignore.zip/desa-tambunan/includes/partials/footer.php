<!-- Footer -->
<footer class="bg-primary text-on-primary mt-auto">
<div class="w-full py-section-gap-mobile md:py-section-gap-desktop px-margin-mobile md:px-gutter flex flex-col md:flex-row justify-between items-start max-w-container-max-width mx-auto">
<div class="mb-12 md:mb-0 max-w-sm">
<div class="font-headline-sm text-headline-sm text-secondary-fixed mb-6">Kelurahan Tambunan</div>
<p class="font-body-md text-body-md opacity-70 mb-8">
                    Menjaga tradisi, merawat alam, membangun masa depan yang berkelanjutan bagi generasi mendatang.
                </p>
</div>
<div class="grid grid-cols-2 gap-16">
<div>
<h4 class="font-label-lg uppercase tracking-widest text-gold-accent mb-6">Navigasi</h4>
<ul class="space-y-4">
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="index.php#home">Home</a></li>
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="index.php#profil-desa">Profil Desa</a></li>
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="index.php#fasilitas-umum">Fasilitas Umum</a></li>
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="artikel.php">Artikel</a></li>
</ul>
</div>
<div>
<h4 class="font-label-lg uppercase tracking-widest text-gold-accent mb-6">Layanan</h4>
<ul class="space-y-4">
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="legal-corner.php">Legal Corner</a></li>
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="legal-tanya.php">Tanya Hukum</a></li>
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="legal-buku.php">Unduh Buku Saku</a></li>
<li><a class="opacity-70 hover:text-secondary-fixed-dim transition-all" href="legal-darurat.php">Kontak Darurat</a></li>
</ul>
</div>
</div>
</div>
<div class="max-w-container-max-width mx-auto px-margin-mobile md:px-gutter py-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-3 text-center md:text-left">
<p class="font-label-md text-label-md opacity-50">&copy; 2024 Pemerintah Kelurahan Tambunan. All Rights Reserved.</p>
<a class="font-label-md text-label-md opacity-40 hover:opacity-80 hover:text-secondary-fixed-dim underline transition-all" href="admin/login.php">Login Admin</a>
</div>
</footer>
<script src="js/main.js"></script>
</body>
</html>
