<?php
/**
 * Partial: Header (head + navbar)
 * Dipakai oleh halaman-halaman baru (artikel, legal-corner, dll)
 * Wajib set $page_title dan $page_description sebelum include file ini.
 */
$page_title = $page_title ?? 'Kelurahan Tambunan';
$page_description = $page_description ?? 'Situs resmi Kelurahan Tambunan, Tana Toraja.';
?>
<!DOCTYPE html>
<html class="scroll-smooth" lang="id">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title><?= htmlspecialchars($page_title) ?> | Kelurahan Tambunan</title>
<meta content="<?= htmlspecialchars($page_description) ?>" name="description"/>
<link href="assets/favicon.ico" rel="icon" type="image/x-icon"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<script src="js/tailwind-config.js"></script>
<link href="css/style.css" rel="stylesheet"/>
</head>
<body class="bg-background text-on-background font-body-md">
<!-- TopNavBar -->
<header class="sticky top-0 w-full z-50 bg-primary transition-all duration-300 h-20 flex items-center">
<div class="flex justify-between items-center w-full px-margin-mobile md:px-gutter max-w-container-max-width mx-auto">
<a class="flex items-center gap-2 md:gap-3" href="index.php">
<img alt="Logo Kabupaten Tana Toraja" class="h-7 w-7 md:h-10 md:w-10 object-contain shrink-0" src="assets/images/logo/logo-kecamatan.png"/>
<span class="font-headline-md text-base sm:text-lg md:text-headline-md text-secondary-fixed leading-tight">
                Kelurahan Tambunan
            </span>
</a>
<nav class="hidden md:flex gap-6 items-center">
<a class="font-label-lg text-label-lg text-on-primary opacity-80 hover:opacity-100 transition-opacity hover:text-secondary-fixed pb-1 border-b-2 border-transparent" href="index.php#home">Home</a>
<a class="font-label-lg text-label-lg text-on-primary opacity-80 hover:opacity-100 transition-opacity hover:text-secondary-fixed pb-1 border-b-2 border-transparent" href="index.php#profil-desa">Profil Desa</a>
<div class="relative group">
<button class="font-label-lg text-label-lg text-on-primary opacity-80 hover:opacity-100 transition-opacity hover:text-secondary-fixed pb-1 border-b-2 border-transparent flex items-center gap-1" type="button">
Wisata
<span class="material-symbols-outlined text-base">expand_more</span>
</button>
<div class="absolute top-full left-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
<div class="bg-primary luxury-shadow py-2 w-64">
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="index.php#struktur-pemerintahan">Struktur Pemerintahan</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="index.php#fasilitas-umum">Fasilitas Umum</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="index.php#potensi-desa">Potensi Desa</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="index.php#galeri">Galeri</a>
</div>
</div>
</div>
<div class="relative group">
<button class="font-label-lg text-label-lg text-on-primary opacity-80 hover:opacity-100 transition-opacity hover:text-secondary-fixed pb-1 border-b-2 border-transparent flex items-center gap-1" type="button">
Layanan
<span class="material-symbols-outlined text-base">expand_more</span>
</button>
<div class="absolute top-full left-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
<div class="bg-primary luxury-shadow py-2 w-64">
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="legal-corner.php">Legal Corner</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="legal-informasi.php">Informasi Hukum</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="legal-tanya.php">Tanya Hukum</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="legal-rujukan.php">Rujukan &amp; Kontak Darurat</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="legal-buku.php">Unduh Buku Saku</a>
</div>
</div>
</div>
<div class="relative group">
<button class="font-label-lg text-label-lg text-on-primary opacity-80 hover:opacity-100 transition-opacity hover:text-secondary-fixed pb-1 border-b-2 border-transparent flex items-center gap-1" type="button">
Berita
<span class="material-symbols-outlined text-base">expand_more</span>
</button>
<div class="absolute top-full left-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
<div class="bg-primary luxury-shadow py-2 w-56">
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="index.php#berita">Berita</a>
<a class="block px-5 py-3 text-on-primary opacity-80 hover:opacity-100 hover:bg-white/5 transition-all" href="artikel.php">Artikel</a>
</div>
</div>
</div>
<a class="font-label-lg text-label-lg text-on-primary opacity-80 hover:opacity-100 transition-opacity hover:text-secondary-fixed pb-1 border-b-2 border-transparent" href="index.php#kontak">Kontak</a>
<a class="bg-gold-accent text-primary px-5 py-2 text-sm font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" href="admin/login.php">Login</a>
</nav>
<button aria-controls="mobile-menu" aria-expanded="false" aria-label="Buka menu" class="md:hidden flex flex-col justify-center items-center w-10 h-10 gap-1.5" id="hamburger-btn">
<span class="block w-6 h-0.5 bg-on-primary transition-all" id="bar1"></span>
<span class="block w-6 h-0.5 bg-on-primary transition-all" id="bar2"></span>
<span class="block w-6 h-0.5 bg-on-primary transition-all" id="bar3"></span>
</button>
</div>
<nav class="hidden md:hidden flex-col gap-1 bg-primary px-margin-mobile py-6 max-h-[calc(100vh-5rem)] overflow-y-auto absolute top-20 left-0 w-full" id="mobile-menu">
<a class="font-label-lg text-label-lg text-on-primary py-3 border-b border-white/10" href="index.php#home">Home</a>
<a class="font-label-lg text-label-lg text-on-primary py-3 border-b border-white/10" href="index.php#profil-desa">Profil Desa</a>
<span class="text-gold-accent text-xs uppercase tracking-widest pt-4 pb-1 block">Wisata</span>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="index.php#struktur-pemerintahan">Struktur Pemerintahan</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="index.php#fasilitas-umum">Fasilitas Umum</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="index.php#potensi-desa">Potensi Desa</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="index.php#galeri">Galeri</a>
<span class="text-gold-accent text-xs uppercase tracking-widest pt-4 pb-1 block">Layanan</span>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="legal-corner.php">Legal Corner</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="legal-informasi.php">Informasi Hukum</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="legal-tanya.php">Tanya Hukum</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="legal-rujukan.php">Rujukan &amp; Kontak Darurat</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="legal-buku.php">Unduh Buku Saku</a>
<span class="text-gold-accent text-xs uppercase tracking-widest pt-4 pb-1 block">Berita</span>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="index.php#berita">Berita</a>
<a class="font-label-lg text-label-lg text-on-primary py-2 pl-3 border-b border-white/10" href="artikel.php">Artikel</a>
<a class="font-label-lg text-label-lg text-on-primary py-3 mt-2" href="index.php#kontak">Kontak</a>
</nav>
</header>
