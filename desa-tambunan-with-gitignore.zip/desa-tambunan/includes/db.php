<?php
/**
 * Koneksi Database (PDO)
 * -----------------------
 * GANTI 4 nilai di bawah sesuai data database di hosting kamu.
 * Kalau pakai cPanel, biasanya nama database & username diawali
 * dengan prefix akun hosting, misal: "namauser_desatambunan".
 */

// Jangan tampilkan error PHP ke publik (keamanan) — tetap dicatat ke file log server
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

define('DB_HOST', 'localhost');
define('DB_NAME', 'desatambunan');
define('DB_USER', 'root');
define('DB_PASS', '');

function get_db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Jangan tampilkan detail error database ke publik
            error_log('DB Connection failed: ' . $e->getMessage());
            throw new RuntimeException('Koneksi database gagal.');
        }
    }

    return $pdo;
}
