<?php
/**
 * Helper Upload Foto
 * -------------------
 * Dipakai oleh endpoint admin (hero, potensi, galeri) untuk
 * menyimpan file foto yang diupload dengan aman.
 */

define('UPLOAD_MAX_BYTES', 5 * 1024 * 1024); // 5MB
define('UPLOAD_ALLOWED_MIME', ['image/jpeg', 'image/png', 'image/webp']);
define('UPLOAD_ALLOWED_EXT', ['jpg', 'jpeg', 'png', 'webp']);

/**
 * @param array  $file      Salah satu elemen dari $_FILES
 * @param string $subfolder Nama folder tujuan di dalam assets/images/ (mis. 'hero', 'potensi', 'galeri')
 * @return array ['success' => bool, 'path' => string|null, 'message' => string]
 */
function handle_image_upload(array $file, string $subfolder): array
{
    if (empty($file) || !isset($file['error']) || is_array($file['error'])) {
        // Tidak ada file yang dikirim sama sekali — bukan error, cuma tidak ada perubahan foto
        return ['success' => true, 'path' => null, 'message' => ''];
    }

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        // Tidak ada file baru diupload — bukan error, cuma tidak ada perubahan foto
        return ['success' => true, 'path' => null, 'message' => ''];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'path' => null, 'message' => 'Gagal mengupload file (kode error: ' . $file['error'] . ').'];
    }

    if ($file['size'] > UPLOAD_MAX_BYTES) {
        return ['success' => false, 'path' => null, 'message' => 'Ukuran foto maksimal 5MB. Kompres dulu foto kamu (misal pakai squoosh.app).'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, UPLOAD_ALLOWED_MIME, true)) {
        return ['success' => false, 'path' => null, 'message' => 'Format foto harus JPG, PNG, atau WEBP.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, UPLOAD_ALLOWED_EXT, true)) {
        $ext = ($mime === 'image/png') ? 'png' : (($mime === 'image/webp') ? 'webp' : 'jpg');
    }

    $subfolder = preg_replace('/[^a-z0-9_-]/i', '', $subfolder);
    $targetDir = __DIR__ . '/../assets/images/' . $subfolder . '/';

    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $filename = $subfolder . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
    $targetPath = $targetDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => false, 'path' => null, 'message' => 'Gagal menyimpan file ke server.'];
    }

    // Path relatif yang disimpan ke database & dipakai di <img src="">
    $relativePath = 'assets/images/' . $subfolder . '/' . $filename;

    return ['success' => true, 'path' => $relativePath, 'message' => 'Foto berhasil diupload.'];
}

/**
 * Upload file PDF (dipakai fitur Buku Saku Legal Corner)
 * @param array $file Salah satu elemen dari $_FILES
 * @return array ['success' => bool, 'path' => string|null, 'message' => string]
 */
function handle_pdf_upload(array $file): array
{
    if (empty($file) || !isset($file['error']) || is_array($file['error'])) {
        return ['success' => true, 'path' => null, 'message' => ''];
    }

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => true, 'path' => null, 'message' => ''];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'path' => null, 'message' => 'Gagal mengupload file (kode error: ' . $file['error'] . ').'];
    }

    $maxPdfBytes = 10 * 1024 * 1024; // 10MB untuk dokumen PDF
    if ($file['size'] > $maxPdfBytes) {
        return ['success' => false, 'path' => null, 'message' => 'Ukuran PDF maksimal 10MB.'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if ($mime !== 'application/pdf') {
        return ['success' => false, 'path' => null, 'message' => 'File harus berformat PDF.'];
    }

    $targetDir = __DIR__ . '/../assets/files/buku-saku/';
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $filename = 'buku-' . bin2hex(random_bytes(6)) . '.pdf';
    $targetPath = $targetDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => false, 'path' => null, 'message' => 'Gagal menyimpan file ke server.'];
    }

    return ['success' => true, 'path' => 'assets/files/buku-saku/' . $filename, 'message' => 'PDF berhasil diupload.'];
}
