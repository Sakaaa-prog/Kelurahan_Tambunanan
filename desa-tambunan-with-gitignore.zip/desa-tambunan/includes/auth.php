<?php
/**
 * Helper Autentikasi & Session
 */

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure'   => $isHttps, // otomatis aktif kalau situs diakses via HTTPS
        ]);
        session_start();
    }
}

function is_logged_in(): bool
{
    start_secure_session();
    return !empty($_SESSION['admin_id']);
}

/**
 * Panggil ini di awal setiap halaman/endpoint admin.
 * Kalau belum login, langsung redirect / hentikan proses.
 */
function require_login(bool $is_api = false): void
{
    start_secure_session();

    // Auto logout setelah 30 menit tidak aktif
    $timeout = 1800;
    if (!empty($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
        $_SESSION = [];
        session_destroy();
    }

    if (empty($_SESSION['admin_id'])) {
        if ($is_api) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Sesi login tidak valid. Silakan login kembali.']);
            exit;
        }
        header('Location: login.php');
        exit;
    }

    $_SESSION['last_activity'] = time();
}

/**
 * Validasi CSRF token sederhana untuk form admin.
 */
function csrf_token(): string
{
    start_secure_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(?string $token): bool
{
    start_secure_session();
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string) $token);
}
