<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/upload.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id        = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$judul     = trim($_POST['judul'] ?? '');
$ringkasan = trim($_POST['ringkasan'] ?? '');
$konten    = trim($_POST['konten'] ?? '');
$penulis   = trim($_POST['penulis'] ?? '') ?: 'Admin';
$tanggal   = trim($_POST['tanggal'] ?? '');
$urutan    = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($judul === '' || $ringkasan === '' || $konten === '' || $tanggal === '') {
    echo json_encode(['success' => false, 'message' => 'Judul, ringkasan, konten, dan tanggal wajib diisi.']);
    exit;
}

$dateObj = DateTime::createFromFormat('Y-m-d', $tanggal);
if (!$dateObj || $dateObj->format('Y-m-d') !== $tanggal) {
    echo json_encode(['success' => false, 'message' => 'Format tanggal tidak valid.']);
    exit;
}

$upload = handle_image_upload($_FILES['image'] ?? [], 'artikel');
if (!$upload['success']) {
    echo json_encode(['success' => false, 'message' => $upload['message']]);
    exit;
}

if (!$id && $upload['path'] === null) {
    echo json_encode(['success' => false, 'message' => 'Foto sampul wajib diupload untuk artikel baru.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        if ($upload['path'] !== null) {
            $stmt = $pdo->prepare('UPDATE artikel SET judul = :judul, ringkasan = :ringkasan, konten = :konten, penulis = :penulis, image_path = :image_path, tanggal = :tanggal, urutan = :urutan WHERE id = :id');
            $stmt->execute(['judul' => $judul, 'ringkasan' => $ringkasan, 'konten' => $konten, 'penulis' => $penulis, 'image_path' => $upload['path'], 'tanggal' => $tanggal, 'urutan' => $urutan, 'id' => $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE artikel SET judul = :judul, ringkasan = :ringkasan, konten = :konten, penulis = :penulis, tanggal = :tanggal, urutan = :urutan WHERE id = :id');
            $stmt->execute(['judul' => $judul, 'ringkasan' => $ringkasan, 'konten' => $konten, 'penulis' => $penulis, 'tanggal' => $tanggal, 'urutan' => $urutan, 'id' => $id]);
        }
        $message = 'Artikel berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO artikel (judul, ringkasan, konten, penulis, image_path, tanggal, urutan) VALUES (:judul, :ringkasan, :konten, :penulis, :image_path, :tanggal, :urutan)');
        $stmt->execute(['judul' => $judul, 'ringkasan' => $ringkasan, 'konten' => $konten, 'penulis' => $penulis, 'image_path' => $upload['path'], 'tanggal' => $tanggal, 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Artikel baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id, 'image_path' => $upload['path']]);
} catch (Throwable $e) {
    error_log('Artikel save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
