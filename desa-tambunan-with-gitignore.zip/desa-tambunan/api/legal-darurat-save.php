<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id     = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$nama   = trim($_POST['nama'] ?? '');
$nomor  = trim($_POST['nomor'] ?? '');
$urutan = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($nama === '' || $nomor === '') {
    echo json_encode(['success' => false, 'message' => 'Nama dan nomor wajib diisi.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        $stmt = $pdo->prepare('UPDATE legal_darurat SET nama = :nama, nomor = :nomor, urutan = :urutan WHERE id = :id');
        $stmt->execute(['nama' => $nama, 'nomor' => $nomor, 'urutan' => $urutan, 'id' => $id]);
        $message = 'Kontak darurat berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO legal_darurat (nama, nomor, urutan) VALUES (:nama, :nomor, :urutan)');
        $stmt->execute(['nama' => $nama, 'nomor' => $nomor, 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Kontak darurat baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id]);
} catch (Throwable $e) {
    error_log('Legal darurat save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
