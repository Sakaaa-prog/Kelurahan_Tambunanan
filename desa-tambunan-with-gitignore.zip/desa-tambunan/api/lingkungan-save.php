<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id          = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$nama        = trim($_POST['nama'] ?? '');
$kepalaNama  = trim($_POST['kepala_nama'] ?? '');
$kepalaHp    = trim($_POST['kepala_hp'] ?? '');
$urutan      = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($nama === '' || $kepalaNama === '' || $kepalaHp === '') {
    echo json_encode(['success' => false, 'message' => 'Nama Lingkungan, nama kepala, dan No HP wajib diisi.']);
    exit;
}

if (!preg_match('/^[0-9+\-\s]{6,20}$/', $kepalaHp)) {
    echo json_encode(['success' => false, 'message' => 'Format No HP tidak valid.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        $stmt = $pdo->prepare(
            'UPDATE lingkungan SET nama = :nama, kepala_nama = :kepala_nama, kepala_hp = :kepala_hp, urutan = :urutan WHERE id = :id'
        );
        $stmt->execute(['nama' => $nama, 'kepala_nama' => $kepalaNama, 'kepala_hp' => $kepalaHp, 'urutan' => $urutan, 'id' => $id]);
        $message = 'Lingkungan berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO lingkungan (nama, kepala_nama, kepala_hp, urutan) VALUES (:nama, :kepala_nama, :kepala_hp, :urutan)'
        );
        $stmt->execute(['nama' => $nama, 'kepala_nama' => $kepalaNama, 'kepala_hp' => $kepalaHp, 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Lingkungan baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id]);
} catch (Throwable $e) {
    error_log('Lingkungan save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan data ke database.']);
}
