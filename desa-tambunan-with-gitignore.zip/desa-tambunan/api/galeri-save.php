<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/upload.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id       = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$altText  = trim($_POST['alt_text'] ?? '');
$layout   = in_array($_POST['layout'] ?? '', ['normal', 'tall', 'wide'], true) ? $_POST['layout'] : 'normal';
$urutan   = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

$upload = handle_image_upload($_FILES['image'] ?? [], 'galeri');
if (!$upload['success']) {
    echo json_encode(['success' => false, 'message' => $upload['message']]);
    exit;
}

if (!$id && $upload['path'] === null) {
    echo json_encode(['success' => false, 'message' => 'Foto wajib diupload untuk galeri baru.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        if ($upload['path'] !== null) {
            $stmt = $pdo->prepare('UPDATE galeri SET alt_text = :alt_text, layout = :layout, image_path = :image_path, urutan = :urutan WHERE id = :id');
            $stmt->execute(['alt_text' => $altText, 'layout' => $layout, 'image_path' => $upload['path'], 'urutan' => $urutan, 'id' => $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE galeri SET alt_text = :alt_text, layout = :layout, urutan = :urutan WHERE id = :id');
            $stmt->execute(['alt_text' => $altText, 'layout' => $layout, 'urutan' => $urutan, 'id' => $id]);
        }
        $message = 'Foto galeri berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO galeri (alt_text, layout, image_path, urutan) VALUES (:alt_text, :layout, :image_path, :urutan)');
        $stmt->execute(['alt_text' => $altText, 'layout' => $layout, 'image_path' => $upload['path'], 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Foto galeri baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id, 'image_path' => $upload['path']]);
} catch (Throwable $e) {
    error_log('Galeri save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
