<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/upload.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id        = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$kategori  = trim($_POST['kategori'] ?? '');
$judul     = trim($_POST['judul'] ?? '');
$deskripsi = trim($_POST['deskripsi'] ?? '');
$tanggal   = trim($_POST['tanggal'] ?? '');
$urutan    = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($kategori === '' || $judul === '' || $deskripsi === '' || $tanggal === '') {
    echo json_encode(['success' => false, 'message' => 'Kategori, judul, deskripsi, dan tanggal wajib diisi.']);
    exit;
}

$dateObj = DateTime::createFromFormat('Y-m-d', $tanggal);
if (!$dateObj || $dateObj->format('Y-m-d') !== $tanggal) {
    echo json_encode(['success' => false, 'message' => 'Format tanggal tidak valid.']);
    exit;
}

$upload = handle_image_upload($_FILES['image'] ?? [], 'berita');
if (!$upload['success']) {
    echo json_encode(['success' => false, 'message' => $upload['message']]);
    exit;
}

if (!$id && $upload['path'] === null) {
    echo json_encode(['success' => false, 'message' => 'Foto wajib diupload untuk berita baru.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        if ($upload['path'] !== null) {
            $stmt = $pdo->prepare('UPDATE berita SET kategori = :kategori, judul = :judul, deskripsi = :deskripsi, tanggal = :tanggal, image_path = :image_path, urutan = :urutan WHERE id = :id');
            $stmt->execute(['kategori' => $kategori, 'judul' => $judul, 'deskripsi' => $deskripsi, 'tanggal' => $tanggal, 'image_path' => $upload['path'], 'urutan' => $urutan, 'id' => $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE berita SET kategori = :kategori, judul = :judul, deskripsi = :deskripsi, tanggal = :tanggal, urutan = :urutan WHERE id = :id');
            $stmt->execute(['kategori' => $kategori, 'judul' => $judul, 'deskripsi' => $deskripsi, 'tanggal' => $tanggal, 'urutan' => $urutan, 'id' => $id]);
        }
        $message = 'Berita berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO berita (kategori, judul, deskripsi, tanggal, image_path, urutan) VALUES (:kategori, :judul, :deskripsi, :tanggal, :image_path, :urutan)');
        $stmt->execute(['kategori' => $kategori, 'judul' => $judul, 'deskripsi' => $deskripsi, 'tanggal' => $tanggal, 'image_path' => $upload['path'], 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Berita baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id, 'image_path' => $upload['path']]);
} catch (Throwable $e) {
    error_log('Berita save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
