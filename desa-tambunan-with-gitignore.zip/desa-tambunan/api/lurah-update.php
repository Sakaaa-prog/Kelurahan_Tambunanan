<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$nama = trim($_POST['nama'] ?? '');
$no_hp = trim($_POST['no_hp'] ?? '');

if ($nama === '' || $no_hp === '') {
    echo json_encode(['success' => false, 'message' => 'Nama dan No HP wajib diisi.']);
    exit;
}

if (!preg_match('/^[0-9+\-\s]{6,20}$/', $no_hp)) {
    echo json_encode(['success' => false, 'message' => 'Format No HP tidak valid.']);
    exit;
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare('UPDATE lurah SET nama = :nama, no_hp = :no_hp WHERE id = 1');
    $stmt->execute(['nama' => $nama, 'no_hp' => $no_hp]);

    echo json_encode(['success' => true, 'message' => 'Data Lurah berhasil disimpan.']);
} catch (Throwable $e) {
    error_log('Lurah update error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan data ke database.']);
}
