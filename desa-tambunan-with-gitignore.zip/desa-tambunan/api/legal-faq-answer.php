<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id            = isset($_POST['id']) ? (int) $_POST['id'] : 0;
$jawaban       = trim($_POST['jawaban'] ?? '');
$tampilPublik  = isset($_POST['tampil_publik']) && $_POST['tampil_publik'] === '1' ? 1 : 0;

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID tidak valid.']);
    exit;
}

if ($jawaban === '') {
    echo json_encode(['success' => false, 'message' => 'Jawaban tidak boleh kosong.']);
    exit;
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare("UPDATE legal_faq SET jawaban = :jawaban, status = 'dijawab', tampil_publik = :tampil_publik WHERE id = :id");
    $stmt->execute(['jawaban' => $jawaban, 'tampil_publik' => $tampilPublik, 'id' => $id]);

    // Ambil email penanya supaya admin bisa follow-up manual
    $stmt2 = $pdo->prepare('SELECT nama, email FROM legal_faq WHERE id = :id');
    $stmt2->execute(['id' => $id]);
    $row = $stmt2->fetch();

    echo json_encode([
        'success' => true,
        'message' => 'Jawaban berhasil disimpan. Jangan lupa follow-up manual ke email: ' . ($row['email'] ?? '-'),
    ]);
} catch (Throwable $e) {
    error_log('Legal FAQ answer error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan jawaban.']);
}
