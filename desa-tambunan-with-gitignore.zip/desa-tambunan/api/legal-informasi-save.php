<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id     = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$judul  = trim($_POST['judul'] ?? '');
$isi    = trim($_POST['isi'] ?? '');
$urutan = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($judul === '' || $isi === '') {
    echo json_encode(['success' => false, 'message' => 'Judul dan isi wajib diisi.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        $stmt = $pdo->prepare('UPDATE legal_informasi SET judul = :judul, isi = :isi, urutan = :urutan WHERE id = :id');
        $stmt->execute(['judul' => $judul, 'isi' => $isi, 'urutan' => $urutan, 'id' => $id]);
        $message = 'Informasi berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO legal_informasi (judul, isi, urutan) VALUES (:judul, :isi, :urutan)');
        $stmt->execute(['judul' => $judul, 'isi' => $isi, 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Informasi baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id]);
} catch (Throwable $e) {
    error_log('Legal informasi save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
