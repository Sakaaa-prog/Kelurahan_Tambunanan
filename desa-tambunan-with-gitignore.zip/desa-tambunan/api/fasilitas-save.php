<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id       = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$nama     = trim($_POST['nama'] ?? '');
$gmapsUrl = trim($_POST['gmaps_link'] ?? '');
$urutan   = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($nama === '') {
    echo json_encode(['success' => false, 'message' => 'Nama fasilitas wajib diisi.']);
    exit;
}

if ($gmapsUrl !== '' && !filter_var($gmapsUrl, FILTER_VALIDATE_URL)) {
    echo json_encode(['success' => false, 'message' => 'Link Google Maps tidak valid.']);
    exit;
}

$gmapsValue = $gmapsUrl === '' ? null : $gmapsUrl;

try {
    $pdo = get_db();

    if ($id) {
        $stmt = $pdo->prepare('UPDATE fasilitas_umum SET nama = :nama, gmaps_link = :gmaps_link, urutan = :urutan WHERE id = :id');
        $stmt->execute(['nama' => $nama, 'gmaps_link' => $gmapsValue, 'urutan' => $urutan, 'id' => $id]);
        $message = 'Fasilitas berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO fasilitas_umum (nama, gmaps_link, urutan) VALUES (:nama, :gmaps_link, :urutan)');
        $stmt->execute(['nama' => $nama, 'gmaps_link' => $gmapsValue, 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Fasilitas baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id]);
} catch (Throwable $e) {
    error_log('Fasilitas save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
