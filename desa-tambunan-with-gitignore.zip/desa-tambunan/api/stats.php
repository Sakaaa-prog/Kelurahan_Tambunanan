<?php
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json');

try {
    $pdo = get_db();
    $stmt = $pdo->query('SELECT penduduk, kepala_keluarga, luas_wilayah, jumlah_dusun, ketinggian FROM village_stats WHERE id = 1');
    $stats = $stmt->fetch();

    if (!$stats) {
        throw new RuntimeException('Data statistik belum tersedia.');
    }

    echo json_encode(['success' => true, 'data' => $stats]);
} catch (Throwable $e) {
    error_log('Stats fetch error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal memuat data statistik.']);
}
