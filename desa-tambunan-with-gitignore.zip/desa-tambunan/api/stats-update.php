<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true); // hentikan di sini kalau belum login

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

// Validasi input: semua wajib angka, tidak boleh kosong/negatif
$fields = [
    'penduduk'        => ['type' => 'int'],
    'kepala_keluarga' => ['type' => 'int'],
    'luas_wilayah'    => ['type' => 'float'],
    'jumlah_dusun'    => ['type' => 'int'],
    'ketinggian'      => ['type' => 'int'],
];

$values = [];
$errors = [];

foreach ($fields as $name => $rule) {
    $raw = str_replace(',', '.', trim($_POST[$name] ?? ''));

    if ($raw === '' || !is_numeric($raw)) {
        $errors[] = "Kolom \"$name\" harus berupa angka.";
        continue;
    }

    $num = $rule['type'] === 'int' ? (int) $raw : (float) $raw;

    if ($num < 0) {
        $errors[] = "Kolom \"$name\" tidak boleh bernilai negatif.";
        continue;
    }

    $values[$name] = $num;
}

if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
    exit;
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare(
        'UPDATE village_stats SET
            penduduk = :penduduk,
            kepala_keluarga = :kepala_keluarga,
            luas_wilayah = :luas_wilayah,
            jumlah_dusun = :jumlah_dusun,
            ketinggian = :ketinggian
         WHERE id = 1'
    );
    $stmt->execute($values);

    echo json_encode(['success' => true, 'message' => 'Data statistik berhasil disimpan.']);
} catch (Throwable $e) {
    error_log('Stats update error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan data ke database.']);
}
