<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/upload.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id        = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$judul     = trim($_POST['judul'] ?? '');
$deskripsi = trim($_POST['deskripsi'] ?? '');
$urutan    = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($judul === '' || $deskripsi === '') {
    echo json_encode(['success' => false, 'message' => 'Judul dan deskripsi wajib diisi.']);
    exit;
}

$upload = handle_image_upload($_FILES['image'] ?? [], 'potensi');
if (!$upload['success']) {
    echo json_encode(['success' => false, 'message' => $upload['message']]);
    exit;
}

// Kalau tambah kartu baru, foto WAJIB ada
if (!$id && $upload['path'] === null) {
    echo json_encode(['success' => false, 'message' => 'Foto wajib diupload untuk kartu baru.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        if ($upload['path'] !== null) {
            $stmt = $pdo->prepare('UPDATE potensi SET judul = :judul, deskripsi = :deskripsi, image_path = :image_path, urutan = :urutan WHERE id = :id');
            $stmt->execute(['judul' => $judul, 'deskripsi' => $deskripsi, 'image_path' => $upload['path'], 'urutan' => $urutan, 'id' => $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE potensi SET judul = :judul, deskripsi = :deskripsi, urutan = :urutan WHERE id = :id');
            $stmt->execute(['judul' => $judul, 'deskripsi' => $deskripsi, 'urutan' => $urutan, 'id' => $id]);
        }
        $message = 'Kartu Potensi Desa berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO potensi (judul, deskripsi, image_path, urutan) VALUES (:judul, :deskripsi, :image_path, :urutan)');
        $stmt->execute(['judul' => $judul, 'deskripsi' => $deskripsi, 'image_path' => $upload['path'], 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Kartu Potensi Desa baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id, 'image_path' => $upload['path']]);
} catch (Throwable $e) {
    error_log('Potensi save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
