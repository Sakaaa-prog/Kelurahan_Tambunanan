<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

start_secure_session();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = (string) ($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Username dan password wajib diisi.']);
    exit;
}

// Rate limiting sederhana berbasis session (anti brute-force kasar)
$_SESSION['login_attempts'] = $_SESSION['login_attempts'] ?? 0;
$_SESSION['login_attempts_time'] = $_SESSION['login_attempts_time'] ?? time();

if (time() - $_SESSION['login_attempts_time'] > 300) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['login_attempts_time'] = time();
}

if ($_SESSION['login_attempts'] >= 5) {
    echo json_encode(['success' => false, 'message' => 'Terlalu banyak percobaan gagal. Coba lagi dalam beberapa menit.']);
    exit;
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT id, username, password_hash FROM admins WHERE username = :username LIMIT 1');
    $stmt->execute(['username' => $username]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        $_SESSION['login_attempts']++;
        echo json_encode(['success' => false, 'message' => 'Username atau password salah.']);
        exit;
    }

    // Login sukses
    session_regenerate_id(true);
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['last_activity'] = time();
    $_SESSION['login_attempts'] = 0;

    echo json_encode(['success' => true, 'redirect' => 'dashboard.php']);
} catch (Throwable $e) {
    error_log('Login error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Terjadi kesalahan pada server.']);
}
