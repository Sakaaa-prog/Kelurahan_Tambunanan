<?php
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json');

try {
    $pdo = get_db();

    $lurah = $pdo->query('SELECT nama, no_hp FROM lurah WHERE id = 1')->fetch();

    $lingkunganList = $pdo->query('SELECT id, nama, kepala_nama, kepala_hp FROM lingkungan ORDER BY urutan ASC, id ASC')->fetchAll();

    $rtStmt = $pdo->prepare('SELECT id, nama, ketua_nama, ketua_hp FROM rt WHERE lingkungan_id = :id ORDER BY urutan ASC, id ASC');

    foreach ($lingkunganList as &$l) {
        $rtStmt->execute(['id' => $l['id']]);
        $l['rt'] = $rtStmt->fetchAll();
    }
    unset($l);

    echo json_encode([
        'success' => true,
        'data' => [
            'lurah' => $lurah,
            'lingkungan' => $lingkunganList,
        ],
    ]);
} catch (Throwable $e) {
    error_log('Struktur fetch error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal memuat data struktur pemerintahan.']);
}
