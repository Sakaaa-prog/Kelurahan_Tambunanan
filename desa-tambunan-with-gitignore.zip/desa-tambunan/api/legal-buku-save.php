<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/upload.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id        = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$judul     = trim($_POST['judul'] ?? '');
$deskripsi = trim($_POST['deskripsi'] ?? '');
$urutan    = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($judul === '' || $deskripsi === '') {
    echo json_encode(['success' => false, 'message' => 'Judul dan deskripsi wajib diisi.']);
    exit;
}

$upload = handle_pdf_upload($_FILES['file'] ?? []);
if (!$upload['success']) {
    echo json_encode(['success' => false, 'message' => $upload['message']]);
    exit;
}

if (!$id && $upload['path'] === null) {
    echo json_encode(['success' => false, 'message' => 'File PDF wajib diupload untuk buku saku baru.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        if ($upload['path'] !== null) {
            $stmt = $pdo->prepare('UPDATE legal_buku SET judul = :judul, deskripsi = :deskripsi, file_path = :file_path, urutan = :urutan WHERE id = :id');
            $stmt->execute(['judul' => $judul, 'deskripsi' => $deskripsi, 'file_path' => $upload['path'], 'urutan' => $urutan, 'id' => $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE legal_buku SET judul = :judul, deskripsi = :deskripsi, urutan = :urutan WHERE id = :id');
            $stmt->execute(['judul' => $judul, 'deskripsi' => $deskripsi, 'urutan' => $urutan, 'id' => $id]);
        }
        $message = 'Buku saku berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO legal_buku (judul, deskripsi, file_path, urutan) VALUES (:judul, :deskripsi, :file_path, :urutan)');
        $stmt->execute(['judul' => $judul, 'deskripsi' => $deskripsi, 'file_path' => $upload['path'], 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Buku saku baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id, 'file_path' => $upload['path']]);
} catch (Throwable $e) {
    error_log('Legal buku save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
