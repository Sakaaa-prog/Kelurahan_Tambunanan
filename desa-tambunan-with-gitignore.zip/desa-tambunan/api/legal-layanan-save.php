<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id           = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$namaInstansi = trim($_POST['nama_instansi'] ?? '');
$deskripsi    = trim($_POST['deskripsi'] ?? '');
$kontak       = trim($_POST['kontak'] ?? '');
$urutan       = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($namaInstansi === '' || $deskripsi === '' || $kontak === '') {
    echo json_encode(['success' => false, 'message' => 'Nama instansi, deskripsi, dan kontak wajib diisi.']);
    exit;
}

try {
    $pdo = get_db();

    if ($id) {
        $stmt = $pdo->prepare('UPDATE legal_layanan SET nama_instansi = :nama_instansi, deskripsi = :deskripsi, kontak = :kontak, urutan = :urutan WHERE id = :id');
        $stmt->execute(['nama_instansi' => $namaInstansi, 'deskripsi' => $deskripsi, 'kontak' => $kontak, 'urutan' => $urutan, 'id' => $id]);
        $message = 'Rujukan layanan berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO legal_layanan (nama_instansi, deskripsi, kontak, urutan) VALUES (:nama_instansi, :deskripsi, :kontak, :urutan)');
        $stmt->execute(['nama_instansi' => $namaInstansi, 'deskripsi' => $deskripsi, 'kontak' => $kontak, 'urutan' => $urutan]);
        $id = (int) $pdo->lastInsertId();
        $message = 'Rujukan layanan baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id]);
} catch (Throwable $e) {
    error_log('Legal layanan save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
