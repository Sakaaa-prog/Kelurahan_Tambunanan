<?php
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

$nama = trim($_POST['nama'] ?? '');
$email = trim($_POST['email'] ?? '');
$pertanyaan = trim($_POST['pertanyaan'] ?? '');

if ($nama === '' || $email === '' || $pertanyaan === '') {
    echo json_encode(['success' => false, 'message' => 'Semua kolom wajib diisi.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Format email tidak valid.']);
    exit;
}

if (mb_strlen($pertanyaan) > 2000) {
    echo json_encode(['success' => false, 'message' => 'Pertanyaan terlalu panjang (maksimal 2000 karakter).']);
    exit;
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare('INSERT INTO legal_faq (nama, email, pertanyaan, status) VALUES (:nama, :email, :pertanyaan, \'pending\')');
    $stmt->execute(['nama' => $nama, 'email' => $email, 'pertanyaan' => $pertanyaan]);

    echo json_encode(['success' => true, 'message' => 'Pertanyaan berhasil dikirim. Jawaban akan kami kirim ke email kamu.']);
} catch (Throwable $e) {
    error_log('Legal FAQ submit error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal mengirim pertanyaan. Coba lagi nanti.']);
}
