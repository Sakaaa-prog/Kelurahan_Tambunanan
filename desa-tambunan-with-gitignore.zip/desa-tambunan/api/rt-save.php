<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$id            = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$lingkunganId  = isset($_POST['lingkungan_id']) ? (int) $_POST['lingkungan_id'] : 0;
$nama          = trim($_POST['nama'] ?? '');
$ketuaNama     = trim($_POST['ketua_nama'] ?? '');
$ketuaHp       = trim($_POST['ketua_hp'] ?? '');
$urutan        = isset($_POST['urutan']) && $_POST['urutan'] !== '' ? (int) $_POST['urutan'] : 0;

if ($lingkunganId <= 0 || $nama === '' || $ketuaNama === '' || $ketuaHp === '') {
    echo json_encode(['success' => false, 'message' => 'Lingkungan, nama RT, nama ketua, dan No HP wajib diisi.']);
    exit;
}

if (!preg_match('/^[0-9+\-\s]{6,20}$/', $ketuaHp)) {
    echo json_encode(['success' => false, 'message' => 'Format No HP tidak valid.']);
    exit;
}

try {
    $pdo = get_db();

    // Pastikan lingkungan_id yang dikirim benar-benar ada
    $check = $pdo->prepare('SELECT id FROM lingkungan WHERE id = :id');
    $check->execute(['id' => $lingkunganId]);
    if (!$check->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Lingkungan yang dipilih tidak ditemukan.']);
        exit;
    }

    if ($id) {
        $stmt = $pdo->prepare(
            'UPDATE rt SET lingkungan_id = :lingkungan_id, nama = :nama, ketua_nama = :ketua_nama, ketua_hp = :ketua_hp, urutan = :urutan WHERE id = :id'
        );
        $stmt->execute([
            'lingkungan_id' => $lingkunganId, 'nama' => $nama, 'ketua_nama' => $ketuaNama,
            'ketua_hp' => $ketuaHp, 'urutan' => $urutan, 'id' => $id,
        ]);
        $message = 'RT berhasil diperbarui.';
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO rt (lingkungan_id, nama, ketua_nama, ketua_hp, urutan) VALUES (:lingkungan_id, :nama, :ketua_nama, :ketua_hp, :urutan)'
        );
        $stmt->execute([
            'lingkungan_id' => $lingkunganId, 'nama' => $nama, 'ketua_nama' => $ketuaNama,
            'ketua_hp' => $ketuaHp, 'urutan' => $urutan,
        ]);
        $id = (int) $pdo->lastInsertId();
        $message = 'RT baru berhasil ditambahkan.';
    }

    echo json_encode(['success' => true, 'message' => $message, 'id' => $id]);
} catch (Throwable $e) {
    error_log('RT save error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan data ke database.']);
}
