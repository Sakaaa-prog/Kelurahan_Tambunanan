<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/upload.php';

header('Content-Type: application/json');
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Sesi form kedaluwarsa, silakan muat ulang halaman.']);
    exit;
}

$upload = handle_image_upload($_FILES['image'] ?? [], 'profil');

if (!$upload['success']) {
    echo json_encode(['success' => false, 'message' => $upload['message']]);
    exit;
}

if ($upload['path'] === null) {
    echo json_encode(['success' => false, 'message' => 'Pilih foto baru dulu sebelum menyimpan.']);
    exit;
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare('UPDATE profil SET image_path = :path WHERE id = 1');
    $stmt->execute(['path' => $upload['path']]);

    echo json_encode(['success' => true, 'message' => 'Foto Profil Desa berhasil diperbarui.', 'path' => $upload['path']]);
} catch (Throwable $e) {
    error_log('Profil update error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database.']);
}
