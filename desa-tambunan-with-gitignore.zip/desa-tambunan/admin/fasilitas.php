<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

$pdo = get_db();
$fasilitasList = $pdo->query('SELECT * FROM fasilitas_umum ORDER BY urutan ASC, id ASC')->fetchAll();

$csrfToken = csrf_token();
$adminUsername = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin', ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Kelola Fasilitas Umum | Kelurahan Tambunan</title>
<script src="https://cdn.tailwindcss.com?plugins=forms"></script>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<script src="../js/tailwind-config.js"></script>
<link href="../css/style.css" rel="stylesheet"/>
</head>
<body class="bg-background font-body-md text-on-background">

<header class="bg-primary text-on-primary">
<div class="max-w-5xl mx-auto px-6 py-5 flex flex-col gap-4">
<div class="flex justify-between items-center">
<div class="font-headline-sm text-headline-sm">Dashboard Admin &mdash; Kelurahan Tambunan</div>
<div class="flex items-center gap-6">
<span class="text-sm opacity-80">Masuk sebagai <strong><?= $adminUsername ?></strong></span>
<a class="text-sm border border-white/30 px-4 py-2 hover:bg-white/10 transition-all" href="../api/logout.php">Logout</a>
</div>
</div>
<nav class="flex gap-6 border-t border-white/10 pt-4">
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="dashboard.php">Dashboard Utama</a>
<a class="text-sm font-bold border-b-2 border-secondary-fixed pb-1" href="fasilitas.php">Fasilitas Umum</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="artikel.php">Artikel</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="legal-corner.php">Legal Corner</a>
</nav>
</div>
</header>

<main class="max-w-5xl mx-auto px-6 py-12">

<div id="global-alert" class="hidden px-5 py-4 text-sm mb-8"></div>

<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Fasilitas Umum</h2>
<p class="text-on-surface-variant mb-8">Daftar fasilitas umum di wilayah kelurahan beserta link Google Maps-nya. Kosongkan link kalau lokasinya belum ditemukan di Maps (tombol otomatis jadi abu-abu di halaman publik).</p>

<button class="mb-8 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-fasilitas" type="button">
+ Tambah Fasilitas Baru
</button>

<div class="space-y-3" id="fasilitas-list">
<?php foreach ($fasilitasList as $f): ?>
<form class="bg-surface-container-lowest luxury-shadow p-5 grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 items-end" data-form="fasilitas">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $f['id'] ?>"/>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama Fasilitas</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nama" required type="text" value="<?= htmlspecialchars($f['nama']) ?>"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Link Google Maps (kosongkan jika tidak ada)</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="gmaps_link" placeholder="https://www.google.com/maps/..." type="url" value="<?= htmlspecialchars($f['gmaps_link'] ?? '') ?>"/>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-3 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete-fasilitas="<?= $f['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>

</main>

<template id="tpl-fasilitas-row">
<form class="bg-surface-container-lowest luxury-shadow p-5 grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 items-end" data-form="fasilitas">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama Fasilitas</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nama" required type="text"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Link Google Maps (kosongkan jika tidak ada)</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="gmaps_link" placeholder="https://www.google.com/maps/..." type="url"/>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</div>
</form>
</template>

<script>
const alertBox = document.getElementById('global-alert');
function showAlert(message, isError = false) {
    alertBox.textContent = message;
    alertBox.className = 'px-5 py-4 text-sm mb-8 ' + (isError ? 'bg-error-container text-on-error-container' : 'bg-secondary-container text-on-secondary-container');
    alertBox.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => alertBox.classList.add('hidden'), 5000);
}

async function submitForm(form, url) {
    const formData = new FormData(form);
    const btn = form.querySelector('button[type="submit"]');
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Menyimpan...';
    try {
        const res = await fetch(url, { method: 'POST', body: formData });
        if (res.status === 401) {
            showAlert('Sesi login habis. Silakan login kembali.', true);
            setTimeout(() => (window.location.href = 'login.php'), 1500);
            return null;
        }
        const data = await res.json();
        showAlert(data.message || (data.success ? 'Berhasil.' : 'Gagal.'), !data.success);
        return data;
    } catch (err) {
        showAlert('Tidak dapat terhubung ke server.', true);
        return null;
    } finally {
        btn.disabled = false;
        btn.textContent = original;
    }
}

document.addEventListener('submit', async (e) => {
    if (e.target.matches('form[data-form="fasilitas"]')) {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/fasilitas-save.php');
        if (data && data.success && data.id) {
            e.target.querySelector('input[name="id"]').value = data.id;
        }
    }
});

document.addEventListener('click', async (e) => {
    if (e.target.matches('[data-delete-fasilitas]')) {
        if (!confirm('Yakin ingin menghapus fasilitas ini?')) return;
        const csrf = document.querySelector('input[name="csrf_token"]').value;
        const formData = new FormData();
        formData.append('id', e.target.dataset.deleteFasilitas);
        formData.append('csrf_token', csrf);
        try {
            const res = await fetch('../api/fasilitas-delete.php', { method: 'POST', body: formData });
            const data = await res.json();
            showAlert(data.message, !data.success);
            if (data.success) e.target.closest('form[data-form="fasilitas"]').remove();
        } catch (err) {
            showAlert('Tidak dapat terhubung ke server.', true);
        }
    }
});

document.getElementById('btn-add-fasilitas').addEventListener('click', () => {
    const tpl = document.getElementById('tpl-fasilitas-row');
    document.getElementById('fasilitas-list').appendChild(tpl.content.cloneNode(true));
});
</script>
</body>
</html>
