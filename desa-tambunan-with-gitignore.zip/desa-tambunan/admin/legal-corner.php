<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

$pdo = get_db();
$informasiList = $pdo->query('SELECT * FROM legal_informasi ORDER BY urutan ASC, id ASC')->fetchAll();
$faqList = $pdo->query("SELECT * FROM legal_faq ORDER BY status ASC, created_at DESC")->fetchAll();
$layananList = $pdo->query('SELECT * FROM legal_layanan ORDER BY urutan ASC, id ASC')->fetchAll();
$bukuList = $pdo->query('SELECT * FROM legal_buku ORDER BY urutan ASC, id ASC')->fetchAll();
$daruratList = $pdo->query('SELECT * FROM legal_darurat ORDER BY urutan ASC, id ASC')->fetchAll();

$csrfToken = csrf_token();
$adminUsername = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin', ENT_QUOTES);
$pendingCount = count(array_filter($faqList, fn($f) => $f['status'] === 'pending'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Kelola Legal Corner | Kelurahan Tambunan</title>
<script src="https://cdn.tailwindcss.com?plugins=forms"></script>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<script src="../js/tailwind-config.js"></script>
<link href="../css/style.css" rel="stylesheet"/>
</head>
<body class="bg-background font-body-md text-on-background">

<header class="bg-primary text-on-primary">
<div class="max-w-5xl mx-auto px-6 py-5 flex flex-col gap-4">
<div class="flex justify-between items-center">
<div class="font-headline-sm text-headline-sm">Dashboard Admin &mdash; Kelurahan Tambunan</div>
<div class="flex items-center gap-6">
<span class="text-sm opacity-80">Masuk sebagai <strong><?= $adminUsername ?></strong></span>
<a class="text-sm border border-white/30 px-4 py-2 hover:bg-white/10 transition-all" href="../api/logout.php">Logout</a>
</div>
</div>
<nav class="flex gap-6 border-t border-white/10 pt-4">
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="dashboard.php">Dashboard Utama</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="fasilitas.php">Fasilitas Umum</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="artikel.php">Artikel</a>
<a class="text-sm font-bold border-b-2 border-secondary-fixed pb-1" href="legal-corner.php">Legal Corner</a>
</nav>
</div>
</header>

<main class="max-w-5xl mx-auto px-6 py-12">

<div id="global-alert" class="hidden px-5 py-4 text-sm mb-8"></div>

<h2 class="font-headline-sm text-headline-sm text-primary mb-8">Legal Corner</h2>

<!-- Tab Switcher -->
<div class="flex flex-wrap gap-2 mb-10 border-b border-outline-variant">
<button class="tab-btn px-5 py-3 text-sm font-bold border-b-2 border-primary text-primary" data-tab="informasi" type="button">Informasi Hukum</button>
<button class="tab-btn px-5 py-3 text-sm text-on-surface-variant border-b-2 border-transparent" data-tab="tanya" type="button">Tanya Hukum <?php if ($pendingCount > 0): ?><span class="ml-1 bg-error text-on-error text-xs rounded-full px-2 py-0.5"><?= $pendingCount ?></span><?php endif; ?></button>
<button class="tab-btn px-5 py-3 text-sm text-on-surface-variant border-b-2 border-transparent" data-tab="layanan" type="button">Rujukan &amp; Kontak Darurat</button>
<button class="tab-btn px-5 py-3 text-sm text-on-surface-variant border-b-2 border-transparent" data-tab="buku" type="button">Buku Saku</button>
</div>

<!-- ============ TAB: INFORMASI HUKUM ============ -->
<div class="tab-panel" data-panel="informasi">
<button class="mb-6 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-informasi" type="button">
+ Tambah Informasi Baru
</button>
<div class="space-y-4" id="informasi-list">
<?php foreach ($informasiList as $item): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="informasi">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $item['id'] ?>"/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text" value="<?= htmlspecialchars($item['judul']) ?>"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Isi</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="isi" required rows="3"><?= htmlspecialchars($item['isi']) ?></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-4 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete="informasi" data-id="<?= $item['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>
</div>

<!-- ============ TAB: TANYA HUKUM ============ -->
<div class="tab-panel hidden" data-panel="tanya">
<p class="text-on-surface-variant mb-6 text-sm">Jawab pertanyaan di sini, lalu follow-up manual ke email penanya. Centang "Tampilkan di FAQ publik" kalau jawabannya bermanfaat untuk pengunjung lain.</p>
<div class="space-y-4" id="tanya-list">
<?php foreach ($faqList as $f): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="tanya">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $f['id'] ?>"/>
<div class="flex justify-between items-start mb-3 gap-4">
<div>
<span class="text-xs uppercase tracking-wider <?= $f['status'] === 'pending' ? 'text-error' : 'text-secondary' ?> font-bold"><?= $f['status'] === 'pending' ? 'Belum Dijawab' : 'Sudah Dijawab' ?></span>
<p class="text-sm text-on-surface-variant mt-1"><?= htmlspecialchars($f['nama']) ?> &middot; <?= htmlspecialchars($f['email']) ?> &middot; <?= htmlspecialchars(date('d M Y H:i', strtotime($f['created_at']))) ?></p>
</div>
<button class="border border-error text-error px-3 py-1.5 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all shrink-0" data-delete="tanya" data-id="<?= $f['id'] ?>" type="button">Hapus</button>
</div>
<p class="bg-surface-container-low p-4 text-sm mb-4"><?= nl2br(htmlspecialchars($f['pertanyaan'])) ?></p>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Jawaban</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="jawaban" required rows="3"><?= htmlspecialchars($f['jawaban'] ?? '') ?></textarea>
</label>
<label class="flex items-center gap-2 mb-4 text-sm">
<input <?= $f['tampil_publik'] ? 'checked' : '' ?> name="tampil_publik" type="checkbox" value="1"/>
Tampilkan di FAQ publik (halaman Tanya Hukum)
</label>
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan Jawaban</button>
</form>
<?php endforeach; ?>
<?php if (empty($faqList)): ?>
<p class="text-on-surface-variant text-sm">Belum ada pertanyaan masuk.</p>
<?php endif; ?>
</div>
</div>

<!-- ============ TAB: RUJUKAN LAYANAN ============ -->
<div class="tab-panel hidden" data-panel="layanan">
<h3 class="font-headline-sm text-base text-primary mb-4">Kontak Darurat</h3>
<button class="mb-6 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-darurat" type="button">
+ Tambah Kontak Baru
</button>
<div class="space-y-3 mb-10" id="darurat-list">
<?php foreach ($daruratList as $item): ?>
<form class="bg-surface-container-lowest luxury-shadow p-5 grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 items-end" data-form="darurat">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $item['id'] ?>"/>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nama" required type="text" value="<?= htmlspecialchars($item['nama']) ?>"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nomor</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nomor" required type="text" value="<?= htmlspecialchars($item['nomor']) ?>"/>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-3 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete="darurat" data-id="<?= $item['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>

<h3 class="font-headline-sm text-base text-primary mb-4">Rujukan Layanan</h3>
<button class="mb-6 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-layanan" type="button">
+ Tambah Rujukan Baru
</button>
<div class="space-y-4" id="layanan-list">
<?php foreach ($layananList as $item): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6 grid grid-cols-1 sm:grid-cols-2 gap-3" data-form="layanan">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $item['id'] ?>"/>
<label class="block sm:col-span-2">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama Instansi</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nama_instansi" required type="text" value="<?= htmlspecialchars($item['nama_instansi']) ?>"/>
</label>
<label class="block sm:col-span-2">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="2"><?= htmlspecialchars($item['deskripsi']) ?></textarea>
</label>
<label class="block sm:col-span-2">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Kontak</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="kontak" required type="text" value="<?= htmlspecialchars($item['kontak']) ?>"/>
</label>
<div class="flex gap-2 sm:col-span-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-4 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete="layanan" data-id="<?= $item['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>
</div>

<!-- ============ TAB: BUKU SAKU ============ -->
<div class="tab-panel hidden" data-panel="buku">
<button class="mb-6 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-buku" type="button">
+ Tambah Buku Saku Baru
</button>
<div class="space-y-4" id="buku-list">
<?php foreach ($bukuList as $item): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="buku" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $item['id'] ?>"/>
<p class="text-sm mb-3"><span class="material-symbols-outlined align-middle text-error text-base">picture_as_pdf</span> <a class="underline text-primary" href="../<?= htmlspecialchars($item['file_path']) ?>" target="_blank">Lihat file saat ini</a></p>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ganti File PDF (opsional)</span>
<input accept="application/pdf" class="w-full border border-outline-variant px-3 py-2 text-sm" name="file" type="file"/>
</label>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text" value="<?= htmlspecialchars($item['judul']) ?>"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="2"><?= htmlspecialchars($item['deskripsi']) ?></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-4 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete="buku" data-id="<?= $item['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>
</div>



</main>

<!-- Templates untuk tambah baru -->
<template id="tpl-informasi">
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="informasi">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block mb-3"><span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span><input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text"/></label>
<label class="block mb-4"><span class="text-xs text-on-surface-variant uppercase block mb-1">Isi</span><textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="isi" required rows="3"></textarea></label>
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</form>
</template>

<template id="tpl-layanan">
<form class="bg-surface-container-lowest luxury-shadow p-6 grid grid-cols-1 sm:grid-cols-2 gap-3" data-form="layanan">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block sm:col-span-2"><span class="text-xs text-on-surface-variant uppercase block mb-1">Nama Instansi</span><input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nama_instansi" required type="text"/></label>
<label class="block sm:col-span-2"><span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span><textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="2"></textarea></label>
<label class="block sm:col-span-2"><span class="text-xs text-on-surface-variant uppercase block mb-1">Kontak</span><input class="w-full border border-outline-variant px-3 py-2 text-sm" name="kontak" required type="text"/></label>
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all sm:col-span-2" type="submit">Simpan</button>
</form>
</template>

<template id="tpl-buku">
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="buku" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block mb-3"><span class="text-xs text-on-surface-variant uppercase block mb-1">File PDF (wajib)</span><input accept="application/pdf" class="w-full border border-outline-variant px-3 py-2 text-sm" name="file" required type="file"/></label>
<label class="block mb-3"><span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span><input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text"/></label>
<label class="block mb-4"><span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span><textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="2"></textarea></label>
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</form>
</template>

<template id="tpl-darurat">
<form class="bg-surface-container-lowest luxury-shadow p-5 grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 items-end" data-form="darurat">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block"><span class="text-xs text-on-surface-variant uppercase block mb-1">Nama</span><input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nama" required type="text"/></label>
<label class="block"><span class="text-xs text-on-surface-variant uppercase block mb-1">Nomor</span><input class="w-full border border-outline-variant px-3 py-2 text-sm" name="nomor" required type="text"/></label>
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</form>
</template>

<script>
// --- Tab switching ---
document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach((b) => {
            b.classList.remove('border-primary', 'text-primary', 'font-bold');
            b.classList.add('border-transparent', 'text-on-surface-variant');
        });
        btn.classList.add('border-primary', 'text-primary', 'font-bold');
        btn.classList.remove('border-transparent', 'text-on-surface-variant');

        document.querySelectorAll('.tab-panel').forEach((p) => p.classList.add('hidden'));
        document.querySelector('[data-panel="' + btn.dataset.tab + '"]').classList.remove('hidden');
    });
});

// --- Shared helpers ---
const alertBox = document.getElementById('global-alert');
function showAlert(message, isError = false) {
    alertBox.textContent = message;
    alertBox.className = 'px-5 py-4 text-sm mb-8 ' + (isError ? 'bg-error-container text-on-error-container' : 'bg-secondary-container text-on-secondary-container');
    alertBox.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => alertBox.classList.add('hidden'), 6000);
}

async function submitForm(form, url) {
    const formData = new FormData(form);
    // checkbox tampil_publik: kalau tidak dicentang, FormData tidak menyertakan field-nya sama sekali
    if (form.querySelector('input[name="tampil_publik"]') && !form.querySelector('input[name="tampil_publik"]').checked) {
        formData.append('tampil_publik', '0');
    }
    const btn = form.querySelector('button[type="submit"]');
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Menyimpan...';
    try {
        const res = await fetch(url, { method: 'POST', body: formData });
        if (res.status === 401) {
            showAlert('Sesi login habis. Silakan login kembali.', true);
            setTimeout(() => (window.location.href = 'login.php'), 1500);
            return null;
        }
        const data = await res.json();
        showAlert(data.message || (data.success ? 'Berhasil.' : 'Gagal.'), !data.success);
        return data;
    } catch (err) {
        showAlert('Tidak dapat terhubung ke server.', true);
        return null;
    } finally {
        btn.disabled = false;
        btn.textContent = original;
    }
}

const apiMap = {
    informasi: '../api/legal-informasi-save.php',
    tanya: '../api/legal-faq-answer.php',
    layanan: '../api/legal-layanan-save.php',
    buku: '../api/legal-buku-save.php',
    darurat: '../api/legal-darurat-save.php',
};
const deleteApiMap = {
    informasi: '../api/legal-informasi-delete.php',
    tanya: '../api/legal-faq-delete.php',
    layanan: '../api/legal-layanan-delete.php',
    buku: '../api/legal-buku-delete.php',
    darurat: '../api/legal-darurat-delete.php',
};

document.addEventListener('submit', async (e) => {
    const formType = e.target.dataset.form;
    if (!formType || !apiMap[formType]) return;
    e.preventDefault();

    const data = await submitForm(e.target, apiMap[formType]);
    if (data && data.success) {
        if (data.id) e.target.querySelector('input[name="id"]').value = data.id;
        const fileInput = e.target.querySelector('input[type="file"]');
        if (fileInput) fileInput.value = '';
    }
});

document.addEventListener('click', async (e) => {
    if (!e.target.matches('[data-delete]')) return;
    const type = e.target.dataset.delete;
    const id = e.target.dataset.id;
    if (!confirm('Yakin ingin menghapus data ini?')) return;

    const csrf = document.querySelector('input[name="csrf_token"]').value;
    const formData = new FormData();
    formData.append('id', id);
    formData.append('csrf_token', csrf);

    try {
        const res = await fetch(deleteApiMap[type], { method: 'POST', body: formData });
        const data = await res.json();
        showAlert(data.message, !data.success);
        if (data.success) e.target.closest('form').remove();
    } catch (err) {
        showAlert('Tidak dapat terhubung ke server.', true);
    }
});

document.getElementById('btn-add-informasi').addEventListener('click', () => {
    document.getElementById('informasi-list').appendChild(document.getElementById('tpl-informasi').content.cloneNode(true));
});
document.getElementById('btn-add-layanan').addEventListener('click', () => {
    document.getElementById('layanan-list').appendChild(document.getElementById('tpl-layanan').content.cloneNode(true));
});
document.getElementById('btn-add-buku').addEventListener('click', () => {
    document.getElementById('buku-list').appendChild(document.getElementById('tpl-buku').content.cloneNode(true));
});
document.getElementById('btn-add-darurat').addEventListener('click', () => {
    document.getElementById('darurat-list').appendChild(document.getElementById('tpl-darurat').content.cloneNode(true));
});
</script>
</body>
</html>
