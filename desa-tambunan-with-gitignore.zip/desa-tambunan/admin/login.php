<?php
require_once __DIR__ . '/../includes/auth.php';

start_secure_session();

// Kalau sudah login, langsung lempar ke dashboard
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Login Admin | Kelurahan Tambunan</title>
<script src="https://cdn.tailwindcss.com?plugins=forms"></script>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
<script src="../js/tailwind-config.js"></script>
<link href="../css/style.css" rel="stylesheet"/>
</head>
<body class="bg-background min-h-screen flex items-center justify-center px-6 font-body-md">
<div class="w-full max-w-md">
<div class="text-center mb-10">
<div class="font-headline-md text-headline-md text-primary mb-2">Kelurahan Tambunan</div>
<p class="text-on-surface-variant">Login Admin</p>
</div>

<form class="bg-surface-container-lowest luxury-shadow p-10" id="login-form">
<div id="form-alert" class="hidden mb-6 px-4 py-3 text-sm bg-error-container text-on-error-container"></div>

<label class="block mb-6">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Username</span>
<input autocomplete="username" class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="username" required type="text"/>
</label>

<label class="block mb-8">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Password</span>
<input autocomplete="current-password" class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="password" required type="password"/>
</label>

<button class="w-full bg-primary text-on-primary py-4 font-label-lg uppercase tracking-widest hover:bg-primary-container transition-all disabled:opacity-50" id="login-submit" type="submit">
Masuk
</button>
</form>

<p class="text-center text-sm text-on-surface-variant mt-8">
<a class="hover:text-primary underline" href="../index.php">&larr; Kembali ke situs utama</a>
</p>
</div>

<script>
document.getElementById('login-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const form = e.target;
    const alertBox = document.getElementById('form-alert');
    const submitBtn = document.getElementById('login-submit');

    alertBox.classList.add('hidden');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Memproses...';

    try {
        const formData = new FormData(form);
        const res = await fetch('../api/login.php', { method: 'POST', body: formData });
        const data = await res.json();

        if (data.success) {
            window.location.href = data.redirect;
        } else {
            alertBox.textContent = data.message || 'Login gagal.';
            alertBox.classList.remove('hidden');
        }
    } catch (err) {
        alertBox.textContent = 'Tidak dapat terhubung ke server. Coba lagi.';
        alertBox.classList.remove('hidden');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Masuk';
    }
});
</script>
</body>
</html>
