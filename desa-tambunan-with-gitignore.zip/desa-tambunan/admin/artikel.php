<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

$pdo = get_db();
$artikelList = $pdo->query('SELECT * FROM artikel ORDER BY urutan ASC, id DESC')->fetchAll();

$csrfToken = csrf_token();
$adminUsername = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin', ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Kelola Artikel | Kelurahan Tambunan</title>
<script src="https://cdn.tailwindcss.com?plugins=forms"></script>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<script src="../js/tailwind-config.js"></script>
<link href="../css/style.css" rel="stylesheet"/>
</head>
<body class="bg-background font-body-md text-on-background">

<header class="bg-primary text-on-primary">
<div class="max-w-5xl mx-auto px-6 py-5 flex flex-col gap-4">
<div class="flex justify-between items-center">
<div class="font-headline-sm text-headline-sm">Dashboard Admin &mdash; Kelurahan Tambunan</div>
<div class="flex items-center gap-6">
<span class="text-sm opacity-80">Masuk sebagai <strong><?= $adminUsername ?></strong></span>
<a class="text-sm border border-white/30 px-4 py-2 hover:bg-white/10 transition-all" href="../api/logout.php">Logout</a>
</div>
</div>
<nav class="flex gap-6 border-t border-white/10 pt-4">
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="dashboard.php">Dashboard Utama</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="fasilitas.php">Fasilitas Umum</a>
<a class="text-sm font-bold border-b-2 border-secondary-fixed pb-1" href="artikel.php">Artikel</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="legal-corner.php">Legal Corner</a>
</nav>
</div>
</header>

<main class="max-w-5xl mx-auto px-6 py-12">

<div id="global-alert" class="hidden px-5 py-4 text-sm mb-8"></div>

<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Artikel</h2>
<p class="text-on-surface-variant mb-8">Tulisan panjang/mendalam tentang kelurahan. Beda dari Berita yang cuma ringkasan singkat.</p>

<button class="mb-8 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-artikel" type="button">
+ Tulis Artikel Baru
</button>

<div class="space-y-6" id="artikel-list">
<?php foreach ($artikelList as $a): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="artikel" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $a['id'] ?>"/>
<img alt="Preview" class="w-full h-48 object-cover mb-4" src="<?= htmlspecialchars($a['image_path']) ?>"/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ganti Foto (opsional)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" type="file"/>
</label>
<div class="grid grid-cols-2 gap-3 mb-3">
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Penulis</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="penulis" required type="text" value="<?= htmlspecialchars($a['penulis']) ?>"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Tanggal</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="tanggal" required type="date" value="<?= htmlspecialchars($a['tanggal']) ?>"/>
</label>
</div>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text" value="<?= htmlspecialchars($a['judul']) ?>"/>
</label>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ringkasan (tampil di halaman daftar artikel)</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" maxlength="300" name="ringkasan" required rows="2"><?= htmlspecialchars($a['ringkasan']) ?></textarea>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Isi Artikel Lengkap (pisahkan paragraf dengan baris baru)</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="konten" required rows="8"><?= htmlspecialchars($a['konten']) ?></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-4 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete-artikel="<?= $a['id'] ?>" type="button">Hapus</button>
<a class="ml-auto text-sm text-primary underline hover:text-gold-accent" href="../artikel-detail.php?id=<?= $a['id'] ?>" target="_blank">Lihat di situs &rarr;</a>
</div>
</form>
<?php endforeach; ?>
</div>

</main>

<template id="tpl-artikel-card">
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="artikel" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Foto (wajib)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" required type="file"/>
</label>
<div class="grid grid-cols-2 gap-3 mb-3">
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Penulis</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="penulis" required type="text" value="Admin"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Tanggal</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="tanggal" required type="date"/>
</label>
</div>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text"/>
</label>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ringkasan (tampil di halaman daftar artikel)</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" maxlength="300" name="ringkasan" required rows="2"></textarea>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Isi Artikel Lengkap (pisahkan paragraf dengan baris baru)</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="konten" required rows="8"></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</div>
</form>
</template>

<script>
const alertBox = document.getElementById('global-alert');
function showAlert(message, isError = false) {
    alertBox.textContent = message;
    alertBox.className = 'px-5 py-4 text-sm mb-8 ' + (isError ? 'bg-error-container text-on-error-container' : 'bg-secondary-container text-on-secondary-container');
    alertBox.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => alertBox.classList.add('hidden'), 5000);
}

async function submitForm(form, url) {
    const formData = new FormData(form);
    const btn = form.querySelector('button[type="submit"]');
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Menyimpan...';
    try {
        const res = await fetch(url, { method: 'POST', body: formData });
        if (res.status === 401) {
            showAlert('Sesi login habis. Silakan login kembali.', true);
            setTimeout(() => (window.location.href = 'login.php'), 1500);
            return null;
        }
        const data = await res.json();
        showAlert(data.message || (data.success ? 'Berhasil.' : 'Gagal.'), !data.success);
        return data;
    } catch (err) {
        showAlert('Tidak dapat terhubung ke server.', true);
        return null;
    } finally {
        btn.disabled = false;
        btn.textContent = original;
    }
}

document.addEventListener('submit', async (e) => {
    if (e.target.matches('form[data-form="artikel"]')) {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/artikel-save.php');
        if (data && data.success) {
            if (data.id) e.target.querySelector('input[name="id"]').value = data.id;
            if (data.image_path) {
                let img = e.target.querySelector('img');
                if (!img) {
                    img = document.createElement('img');
                    img.alt = 'Preview';
                    img.className = 'w-full h-48 object-cover mb-4';
                    e.target.insertBefore(img, e.target.firstElementChild.nextSibling);
                }
                img.src = '../' + data.image_path;
            }
            const fileInput = e.target.querySelector('input[type="file"]');
            if (fileInput) fileInput.value = '';
        }
    }
});

document.addEventListener('click', async (e) => {
    if (e.target.matches('[data-delete-artikel]')) {
        if (!confirm('Yakin ingin menghapus artikel ini?')) return;
        const csrf = document.querySelector('input[name="csrf_token"]').value;
        const formData = new FormData();
        formData.append('id', e.target.dataset.deleteArtikel);
        formData.append('csrf_token', csrf);
        try {
            const res = await fetch('../api/artikel-delete.php', { method: 'POST', body: formData });
            const data = await res.json();
            showAlert(data.message, !data.success);
            if (data.success) e.target.closest('form[data-form="artikel"]').remove();
        } catch (err) {
            showAlert('Tidak dapat terhubung ke server.', true);
        }
    }
});

document.getElementById('btn-add-artikel').addEventListener('click', () => {
    const tpl = document.getElementById('tpl-artikel-card');
    document.getElementById('artikel-list').prepend(tpl.content.cloneNode(true));
});
</script>
</body>
</html>
