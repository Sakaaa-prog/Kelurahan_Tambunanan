<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

$pdo = get_db();
$stats = $pdo->query('SELECT * FROM village_stats WHERE id = 1')->fetch();
$lurah = $pdo->query('SELECT * FROM lurah WHERE id = 1')->fetch();
$lingkunganList = $pdo->query('SELECT * FROM lingkungan ORDER BY urutan ASC, id ASC')->fetchAll();

$hero = $pdo->query('SELECT image_path FROM hero WHERE id = 1')->fetch();
$profil = $pdo->query('SELECT image_path FROM profil WHERE id = 1')->fetch();
$potensiList = $pdo->query('SELECT * FROM potensi ORDER BY urutan ASC, id ASC')->fetchAll();
$galeriList = $pdo->query('SELECT * FROM galeri ORDER BY urutan ASC, id ASC')->fetchAll();
$beritaList = $pdo->query('SELECT * FROM berita ORDER BY urutan ASC, id ASC')->fetchAll();

$rtStmt = $pdo->prepare('SELECT * FROM rt WHERE lingkungan_id = :id ORDER BY urutan ASC, id ASC');
foreach ($lingkunganList as &$l) {
    $rtStmt->execute(['id' => $l['id']]);
    $l['rt'] = $rtStmt->fetchAll();
}
unset($l);

$csrfToken = csrf_token();
$adminUsername = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin', ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Dashboard Admin | Kelurahan Tambunan</title>
<script src="https://cdn.tailwindcss.com?plugins=forms"></script>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<script src="../js/tailwind-config.js"></script>
<link href="../css/style.css" rel="stylesheet"/>
<style>.material-symbols-outlined{font-variation-settings:'FILL' 0,'wght' 400,'GRAD' 0,'opsz' 24;}</style>
</head>
<body class="bg-background font-body-md text-on-background">

<header class="bg-primary text-on-primary">
<div class="max-w-5xl mx-auto px-6 py-5 flex flex-col gap-4">
<div class="flex justify-between items-center">
<div class="font-headline-sm text-headline-sm">Dashboard Admin &mdash; Kelurahan Tambunan</div>
<div class="flex items-center gap-6">
<span class="text-sm opacity-80">Masuk sebagai <strong><?= $adminUsername ?></strong></span>
<a class="text-sm border border-white/30 px-4 py-2 hover:bg-white/10 transition-all" href="../api/logout.php">Logout</a>
</div>
</div>
<nav class="flex gap-6 border-t border-white/10 pt-4">
<a class="text-sm font-bold border-b-2 border-secondary-fixed pb-1" href="dashboard.php">Dashboard Utama</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="fasilitas.php">Fasilitas Umum</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="artikel.php">Artikel</a>
<a class="text-sm opacity-70 hover:opacity-100 transition-opacity" href="legal-corner.php">Legal Corner</a>
</nav>
</div>
</header>

<main class="max-w-5xl mx-auto px-6 py-12 space-y-16">

<div id="global-alert" class="hidden px-5 py-4 text-sm"></div>

<!-- ================= STATISTIK DESA ================= -->
<section>
<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Statistik Desa</h2>
<p class="text-on-surface-variant mb-8">Angka ini tampil di halaman utama website.</p>

<form class="bg-surface-container-lowest luxury-shadow p-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" data-form="stats">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Jumlah Penduduk</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" inputmode="numeric" name="penduduk" required type="number" value="<?= htmlspecialchars($stats['penduduk']) ?>"/>
</label>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Jumlah Keluarga (KK)</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" inputmode="numeric" name="kepala_keluarga" required type="number" value="<?= htmlspecialchars($stats['kepala_keluarga']) ?>"/>
</label>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Luas Wilayah (km&sup2;)</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" inputmode="decimal" name="luas_wilayah" required step="0.01" type="number" value="<?= htmlspecialchars($stats['luas_wilayah']) ?>"/>
</label>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Jumlah Dusun</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" inputmode="numeric" name="jumlah_dusun" required type="number" value="<?= htmlspecialchars($stats['jumlah_dusun']) ?>"/>
</label>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Ketinggian (mdpl)</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" inputmode="numeric" name="ketinggian" required type="number" value="<?= htmlspecialchars($stats['ketinggian']) ?>"/>
</label>

<div class="sm:col-span-2 lg:col-span-3 pt-2">
<button class="bg-primary text-on-primary px-8 py-3 font-label-lg uppercase tracking-widest hover:bg-primary-container transition-all" type="submit">
Simpan Perubahan
</button>
</div>
</form>
</section>

<!-- ================= DATA LURAH ================= -->
<section>
<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Data Lurah</h2>
<p class="text-on-surface-variant mb-8">Nama dan kontak Lurah Tambunan.</p>

<form class="bg-surface-container-lowest luxury-shadow p-8 grid grid-cols-1 sm:grid-cols-2 gap-6" data-form="lurah">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Nama Lurah</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="nama" required type="text" value="<?= htmlspecialchars($lurah['nama']) ?>"/>
</label>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">No HP</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="no_hp" required type="text" value="<?= htmlspecialchars($lurah['no_hp']) ?>"/>
</label>

<div class="sm:col-span-2 pt-2">
<button class="bg-primary text-on-primary px-8 py-3 font-label-lg uppercase tracking-widest hover:bg-primary-container transition-all" type="submit">
Simpan Perubahan
</button>
</div>
</form>
</section>

<!-- ================= FOTO HERO ================= -->
<section>
<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Foto Hero</h2>
<p class="text-on-surface-variant mb-8">Foto besar di paling atas halaman utama.</p>

<form class="bg-surface-container-lowest luxury-shadow p-8" data-form="hero" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<div class="mb-6">
<img alt="Preview foto hero saat ini" class="w-full max-w-md aspect-video object-cover luxury-shadow" src="<?= htmlspecialchars($hero['image_path'] ?? '') ?>"/>
</div>
<label class="block mb-6">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Ganti dengan Foto Baru</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-4 py-3" name="image" type="file"/>
<span class="text-xs text-on-surface-variant block mt-1">Format JPG/PNG/WEBP, maksimal 5MB. Kosongkan kalau tidak mau ganti.</span>
</label>
<button class="bg-primary text-on-primary px-8 py-3 font-label-lg uppercase tracking-widest hover:bg-primary-container transition-all" type="submit">
Upload &amp; Simpan
</button>
</form>
</section>

<!-- ================= FOTO PROFIL DESA ================= -->
<section>
<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Foto Profil Desa</h2>
<p class="text-on-surface-variant mb-8">Foto di section "Profil Desa" (sebelah teks "Harmoni Tradisi dan Kelestarian Alam").</p>

<form class="bg-surface-container-lowest luxury-shadow p-8" data-form="profil" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<div class="mb-6">
<img alt="Preview foto profil saat ini" class="w-full max-w-xs aspect-[4/5] object-cover luxury-shadow" src="<?= htmlspecialchars($profil['image_path'] ?? '') ?>"/>
</div>
<label class="block mb-6">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Ganti dengan Foto Baru</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-4 py-3" name="image" type="file"/>
<span class="text-xs text-on-surface-variant block mt-1">Format JPG/PNG/WEBP, maksimal 5MB. Kosongkan kalau tidak mau ganti.</span>
</label>
<button class="bg-primary text-on-primary px-8 py-3 font-label-lg uppercase tracking-widest hover:bg-primary-container transition-all" type="submit">
Upload &amp; Simpan
</button>
</form>
</section>

<!-- ================= POTENSI DESA ================= -->
<section>
<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Potensi Desa</h2>
<p class="text-on-surface-variant mb-8">Kartu-kartu di section "Potensi Desa" (foto + judul + deskripsi).</p>

<button class="mb-8 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-potensi" type="button">
+ Tambah Kartu Baru
</button>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="potensi-list">
<?php foreach ($potensiList as $p): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="potensi" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $p['id'] ?>"/>
<img alt="Preview" class="w-full h-40 object-cover mb-4" src="<?= htmlspecialchars($p['image_path']) ?>"/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ganti Foto (opsional)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" type="file"/>
</label>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text" value="<?= htmlspecialchars($p['judul']) ?>"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="3"><?= htmlspecialchars($p['deskripsi']) ?></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-4 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete-potensi="<?= $p['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>
</section>

<!-- ================= GALERI ================= -->
<section>
<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Galeri "Jendela Desa"</h2>
<p class="text-on-surface-variant mb-8">Foto-foto di section galeri halaman utama.</p>

<button class="mb-8 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-galeri" type="button">
+ Tambah Foto Baru
</button>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6" id="galeri-list">
<?php foreach ($galeriList as $g): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="galeri" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $g['id'] ?>"/>
<img alt="Preview" class="w-full h-40 object-cover mb-4" src="<?= htmlspecialchars($g['image_path']) ?>"/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ganti Foto (opsional)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" type="file"/>
</label>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Keterangan Foto (alt text)</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="alt_text" type="text" value="<?= htmlspecialchars($g['alt_text']) ?>"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ukuran Kotak</span>
<select class="w-full border border-outline-variant px-3 py-2 text-sm" name="layout">
<option <?= $g['layout'] === 'normal' ? 'selected' : '' ?> value="normal">Normal</option>
<option <?= $g['layout'] === 'tall' ? 'selected' : '' ?> value="tall">Tinggi (Tall)</option>
<option <?= $g['layout'] === 'wide' ? 'selected' : '' ?> value="wide">Lebar (Wide)</option>
</select>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-4 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete-galeri="<?= $g['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>
</section>

<!-- ================= BERITA ================= -->
<section>
<h2 class="font-headline-sm text-headline-sm text-primary mb-2">Berita Terbaru</h2>
<p class="text-on-surface-variant mb-8">Artikel di section "Berita Terbaru" halaman utama.</p>

<button class="mb-8 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-berita" type="button">
+ Tambah Berita Baru
</button>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="berita-list">
<?php foreach ($beritaList as $b): ?>
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="berita" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $b['id'] ?>"/>
<img alt="Preview" class="w-full h-40 object-cover mb-4" src="<?= htmlspecialchars($b['image_path']) ?>"/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ganti Foto (opsional)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" type="file"/>
</label>
<div class="grid grid-cols-2 gap-3 mb-3">
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Kategori</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="kategori" placeholder="mis. Pembangunan" required type="text" value="<?= htmlspecialchars($b['kategori']) ?>"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Tanggal</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="tanggal" required type="date" value="<?= htmlspecialchars($b['tanggal']) ?>"/>
</label>
</div>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text" value="<?= htmlspecialchars($b['judul']) ?>"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="3"><?= htmlspecialchars($b['deskripsi']) ?></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-4 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete-berita="<?= $b['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>
</section>

<!-- ================= LINGKUNGAN & RT ================= -->
<section>
<div class="flex justify-between items-end mb-2">
<h2 class="font-headline-sm text-headline-sm text-primary">Lingkungan &amp; RT</h2>
</div>
<p class="text-on-surface-variant mb-8">Kelola daftar Lingkungan beserta RT di bawahnya.</p>

<button class="mb-8 bg-gold-accent text-primary px-6 py-3 font-label-lg uppercase tracking-widest hover:brightness-110 transition-all" id="btn-add-lingkungan" type="button">
+ Tambah Lingkungan Baru
</button>

<div class="space-y-6" id="lingkungan-list">
<?php foreach ($lingkunganList as $l): ?>
<div class="bg-surface-container-lowest luxury-shadow p-8" data-lingkungan-id="<?= $l['id'] ?>">

<form class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6 items-end" data-form="lingkungan">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $l['id'] ?>"/>

<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Nama Lingkungan</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="nama" required type="text" value="<?= htmlspecialchars($l['nama']) ?>"/>
</label>
<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Nama Kepala Lingkungan</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="kepala_nama" required type="text" value="<?= htmlspecialchars($l['kepala_nama']) ?>"/>
</label>
<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">No HP Kepala Lingkungan</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="kepala_hp" required type="text" value="<?= htmlspecialchars($l['kepala_hp']) ?>"/>
</label>

<div class="sm:col-span-3 flex gap-3">
<button class="bg-primary text-on-primary px-6 py-2.5 font-label-md uppercase tracking-widest hover:bg-primary-container transition-all" type="submit">
Simpan
</button>
<button class="border border-error text-error px-6 py-2.5 font-label-md uppercase tracking-widest hover:bg-error hover:text-on-error transition-all" data-delete-lingkungan="<?= $l['id'] ?>" type="button">
Hapus Lingkungan Ini
</button>
</div>
</form>

<div class="border-t border-outline-variant pt-6">
<h4 class="font-label-lg uppercase tracking-widest text-on-surface-variant mb-4">Daftar RT</h4>

<div class="space-y-3 mb-4" data-rt-list>
<?php foreach ($l['rt'] as $rt): ?>
<form class="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end bg-surface-container-low p-4" data-form="rt">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value="<?= $rt['id'] ?>"/>
<input name="lingkungan_id" type="hidden" value="<?= $l['id'] ?>"/>

<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama RT</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm focus:outline-none focus:border-primary" name="nama" required type="text" value="<?= htmlspecialchars($rt['nama']) ?>"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama Ketua RT</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm focus:outline-none focus:border-primary" name="ketua_nama" required type="text" value="<?= htmlspecialchars($rt['ketua_nama']) ?>"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">No HP</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm focus:outline-none focus:border-primary" name="ketua_hp" required type="text" value="<?= htmlspecialchars($rt['ketua_hp']) ?>"/>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
<button class="border border-error text-error px-3 py-2 text-xs uppercase tracking-wider hover:bg-error hover:text-on-error transition-all" data-delete-rt="<?= $rt['id'] ?>" type="button">Hapus</button>
</div>
</form>
<?php endforeach; ?>
</div>

<button class="text-sm text-primary underline hover:text-gold-accent transition-colors" data-add-rt="<?= $l['id'] ?>" type="button">
+ Tambah RT di Lingkungan Ini
</button>
</div>
</div>
<?php endforeach; ?>
</div>
</section>

</main>

<!-- Template tersembunyi untuk baris RT baru -->
<template id="tpl-rt-row">
<form class="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end bg-surface-container-low p-4" data-form="rt">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<input name="lingkungan_id" type="hidden" value=""/>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama RT</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm focus:outline-none focus:border-primary" name="nama" required type="text"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Nama Ketua RT</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm focus:outline-none focus:border-primary" name="ketua_nama" required type="text"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">No HP</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm focus:outline-none focus:border-primary" name="ketua_hp" required type="text"/>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</div>
</form>
</template>

<!-- Template tersembunyi untuk kartu Lingkungan baru -->
<template id="tpl-lingkungan-card">
<div class="bg-surface-container-lowest luxury-shadow p-8" data-lingkungan-id="">
<form class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6 items-end" data-form="lingkungan">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Nama Lingkungan</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="nama" required type="text"/>
</label>
<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">Nama Kepala Lingkungan</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="kepala_nama" required type="text"/>
</label>
<label class="block">
<span class="font-label-md text-on-surface-variant uppercase block mb-2">No HP Kepala Lingkungan</span>
<input class="w-full border border-outline-variant px-4 py-3 focus:outline-none focus:border-primary" name="kepala_hp" required type="text"/>
</label>
<div class="sm:col-span-3 flex gap-3">
<button class="bg-primary text-on-primary px-6 py-2.5 font-label-md uppercase tracking-widest hover:bg-primary-container transition-all" type="submit">Simpan</button>
</div>
</form>
<div class="border-t border-outline-variant pt-6">
<h4 class="font-label-lg uppercase tracking-widest text-on-surface-variant mb-4">Daftar RT</h4>
<div class="space-y-3 mb-4" data-rt-list></div>
<p class="text-sm text-on-surface-variant italic">Simpan Lingkungan ini dulu, baru RT bisa ditambahkan.</p>
</div>
</div>
</template>

<!-- Template tersembunyi untuk kartu Potensi Desa baru -->
<template id="tpl-potensi-card">
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="potensi" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Foto (wajib)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" required type="file"/>
</label>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="3"></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</div>
</form>
</template>

<!-- Template tersembunyi untuk foto Galeri baru -->
<template id="tpl-galeri-card">
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="galeri" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Foto (wajib)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" required type="file"/>
</label>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Keterangan Foto (alt text)</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="alt_text" type="text"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Ukuran Kotak</span>
<select class="w-full border border-outline-variant px-3 py-2 text-sm" name="layout">
<option value="normal">Normal</option>
<option value="tall">Tinggi (Tall)</option>
<option value="wide">Lebar (Wide)</option>
</select>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</div>
</form>
</template>

<!-- Template tersembunyi untuk Berita baru -->
<template id="tpl-berita-card">
<form class="bg-surface-container-lowest luxury-shadow p-6" data-form="berita" enctype="multipart/form-data">
<input name="csrf_token" type="hidden" value="<?= htmlspecialchars($csrfToken) ?>"/>
<input name="id" type="hidden" value=""/>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Foto (wajib)</span>
<input accept="image/jpeg,image/png,image/webp" class="w-full border border-outline-variant px-3 py-2 text-sm" name="image" required type="file"/>
</label>
<div class="grid grid-cols-2 gap-3 mb-3">
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Kategori</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="kategori" placeholder="mis. Pembangunan" required type="text"/>
</label>
<label class="block">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Tanggal</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="tanggal" required type="date"/>
</label>
</div>
<label class="block mb-3">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Judul</span>
<input class="w-full border border-outline-variant px-3 py-2 text-sm" name="judul" required type="text"/>
</label>
<label class="block mb-4">
<span class="text-xs text-on-surface-variant uppercase block mb-1">Deskripsi</span>
<textarea class="w-full border border-outline-variant px-3 py-2 text-sm" name="deskripsi" required rows="3"></textarea>
</label>
<div class="flex gap-2">
<button class="bg-primary text-on-primary px-4 py-2 text-xs uppercase tracking-wider hover:bg-primary-container transition-all" type="submit">Simpan</button>
</div>
</form>
</template>

<script src="dashboard.js"></script>
</body>
</html>
