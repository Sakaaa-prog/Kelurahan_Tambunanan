const alertBox = document.getElementById('global-alert');

function showAlert(message, isError = false) {
    alertBox.textContent = message;
    alertBox.className = 'px-5 py-4 text-sm ' + (isError ? 'bg-error-container text-on-error-container' : 'bg-secondary-container text-on-secondary-container');
    alertBox.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => alertBox.classList.add('hidden'), 5000);
}

async function submitForm(form, url) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn ? submitBtn.textContent : '';

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Menyimpan...';
    }

    try {
        const res = await fetch(url, { method: 'POST', body: formData });

        if (res.status === 401) {
            showAlert('Sesi login habis. Silakan login kembali.', true);
            setTimeout(() => (window.location.href = 'login.php'), 1500);
            return null;
        }

        const data = await res.json();
        showAlert(data.message || (data.success ? 'Berhasil disimpan.' : 'Gagal menyimpan.'), !data.success);
        return data;
    } catch (err) {
        showAlert('Tidak dapat terhubung ke server.', true);
        return null;
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
        }
    }
}

// --- Form Statistik ---
document.querySelector('form[data-form="stats"]').addEventListener('submit', async (e) => {
    e.preventDefault();
    await submitForm(e.target, '../api/stats-update.php');
});

// --- Form Lurah ---
document.querySelector('form[data-form="lurah"]').addEventListener('submit', async (e) => {
    e.preventDefault();
    await submitForm(e.target, '../api/lurah-update.php');
});

// --- Delegasi event untuk form Lingkungan & RT (termasuk yang ditambah dinamis) ---
document.addEventListener('submit', async (e) => {
    if (e.target.matches('form[data-form="lingkungan"]')) {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/lingkungan-save.php');
        if (data && data.success && data.id) {
            e.target.querySelector('input[name="id"]').value = data.id;
            e.target.closest('[data-lingkungan-id]').dataset.lingkunganId = data.id;
            // update hidden lingkungan_id di semua form RT template baru di kartu ini
            const card = e.target.closest('[data-lingkungan-id]');
            const rtNote = card.querySelector('.italic');
            if (rtNote) rtNote.remove();
            const addRtBtn = card.querySelector('[data-add-rt]');
            if (!addRtBtn) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'text-sm text-primary underline hover:text-gold-accent transition-colors';
                btn.dataset.addRt = data.id;
                btn.textContent = '+ Tambah RT di Lingkungan Ini';
                card.querySelector('.border-t').appendChild(btn);
            } else {
                addRtBtn.dataset.addRt = data.id;
            }
        }
    }

    if (e.target.matches('form[data-form="rt"]')) {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/rt-save.php');
        if (data && data.success && data.id) {
            e.target.querySelector('input[name="id"]').value = data.id;
        }
    }
});

// --- Form Hero ---
const heroForm = document.querySelector('form[data-form="hero"]');
if (heroForm) {
    heroForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/hero-update.php');
        if (data && data.success && data.path) {
            e.target.querySelector('img').src = '../' + data.path;
            e.target.querySelector('input[type="file"]').value = '';
        }
    });
}

// --- Form Profil Desa ---
const profilForm = document.querySelector('form[data-form="profil"]');
if (profilForm) {
    profilForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/profil-update.php');
        if (data && data.success && data.path) {
            e.target.querySelector('img').src = '../' + data.path;
            e.target.querySelector('input[type="file"]').value = '';
        }
    });
}

// --- Delegasi event untuk form Potensi & Galeri (termasuk yang ditambah dinamis) ---
document.addEventListener('submit', async (e) => {
    if (e.target.matches('form[data-form="potensi"]')) {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/potensi-save.php');
        if (data && data.success) {
            if (data.id) e.target.querySelector('input[name="id"]').value = data.id;
            if (data.image_path) {
                let img = e.target.querySelector('img');
                if (!img) {
                    img = document.createElement('img');
                    img.alt = 'Preview';
                    img.className = 'w-full h-40 object-cover mb-4';
                    e.target.insertBefore(img, e.target.firstElementChild.nextSibling);
                }
                img.src = '../' + data.image_path;
            }
            e.target.querySelector('input[type="file"]').value = '';
        }
    }

    if (e.target.matches('form[data-form="galeri"]')) {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/galeri-save.php');
        if (data && data.success) {
            if (data.id) e.target.querySelector('input[name="id"]').value = data.id;
            if (data.image_path) {
                let img = e.target.querySelector('img');
                if (!img) {
                    img = document.createElement('img');
                    img.alt = 'Preview';
                    img.className = 'w-full h-40 object-cover mb-4';
                    e.target.insertBefore(img, e.target.firstElementChild.nextSibling);
                }
                img.src = '../' + data.image_path;
            }
            e.target.querySelector('input[type="file"]').value = '';
        }
    }
    if (e.target.matches('form[data-form="berita"]')) {
        e.preventDefault();
        const data = await submitForm(e.target, '../api/berita-save.php');
        if (data && data.success) {
            if (data.id) e.target.querySelector('input[name="id"]').value = data.id;
            if (data.image_path) {
                let img = e.target.querySelector('img');
                if (!img) {
                    img = document.createElement('img');
                    img.alt = 'Preview';
                    img.className = 'w-full h-40 object-cover mb-4';
                    e.target.insertBefore(img, e.target.firstElementChild.nextSibling);
                }
                img.src = '../' + data.image_path;
            }
            e.target.querySelector('input[type="file"]').value = '';
        }
    }
});

async function deleteRecord(url, id, csrfInputSelector) {
    const csrf = document.querySelector(csrfInputSelector).value;
    const formData = new FormData();
    formData.append('id', id);
    formData.append('csrf_token', csrf);

    try {
        const res = await fetch(url, { method: 'POST', body: formData });
        const data = await res.json();
        showAlert(data.message, !data.success);
        return data.success;
    } catch (err) {
        showAlert('Tidak dapat terhubung ke server.', true);
        return false;
    }
}

document.addEventListener('click', async (e) => {
    if (e.target.matches('[data-delete-potensi]')) {
        if (!confirm('Yakin ingin menghapus kartu Potensi Desa ini?')) return;
        const success = await deleteRecord('../api/potensi-delete.php', e.target.dataset.deletePotensi, 'input[name="csrf_token"]');
        if (success) e.target.closest('form[data-form="potensi"]').remove();
    }

    if (e.target.matches('[data-delete-galeri]')) {
        if (!confirm('Yakin ingin menghapus foto galeri ini?')) return;
        const success = await deleteRecord('../api/galeri-delete.php', e.target.dataset.deleteGaleri, 'input[name="csrf_token"]');
        if (success) e.target.closest('form[data-form="galeri"]').remove();
    }

    if (e.target.matches('[data-delete-berita]')) {
        if (!confirm('Yakin ingin menghapus berita ini?')) return;
        const success = await deleteRecord('../api/berita-delete.php', e.target.dataset.deleteBerita, 'input[name="csrf_token"]');
        if (success) e.target.closest('form[data-form="berita"]').remove();
    }
});

document.getElementById('btn-add-potensi')?.addEventListener('click', () => {
    const tpl = document.getElementById('tpl-potensi-card');
    document.getElementById('potensi-list').appendChild(tpl.content.cloneNode(true));
});

document.getElementById('btn-add-galeri')?.addEventListener('click', () => {
    const tpl = document.getElementById('tpl-galeri-card');
    document.getElementById('galeri-list').appendChild(tpl.content.cloneNode(true));
});

document.getElementById('btn-add-berita')?.addEventListener('click', () => {
    const tpl = document.getElementById('tpl-berita-card');
    document.getElementById('berita-list').appendChild(tpl.content.cloneNode(true));
});

// --- Hapus Lingkungan ---
document.addEventListener('click', async (e) => {
    if (e.target.matches('[data-delete-lingkungan]')) {
        if (!confirm('Yakin ingin menghapus Lingkungan ini beserta seluruh RT di dalamnya?')) return;

        const id = e.target.dataset.deleteLingkungan;
        const csrf = document.querySelector('input[name="csrf_token"]').value;
        const formData = new FormData();
        formData.append('id', id);
        formData.append('csrf_token', csrf);

        try {
            const res = await fetch('../api/lingkungan-delete.php', { method: 'POST', body: formData });
            const data = await res.json();
            showAlert(data.message, !data.success);
            if (data.success) {
                e.target.closest('[data-lingkungan-id]').remove();
            }
        } catch (err) {
            showAlert('Tidak dapat terhubung ke server.', true);
        }
    }

    // --- Hapus RT ---
    if (e.target.matches('[data-delete-rt]')) {
        if (!confirm('Yakin ingin menghapus RT ini?')) return;

        const id = e.target.dataset.deleteRt;
        const csrf = document.querySelector('input[name="csrf_token"]').value;
        const formData = new FormData();
        formData.append('id', id);
        formData.append('csrf_token', csrf);

        try {
            const res = await fetch('../api/rt-delete.php', { method: 'POST', body: formData });
            const data = await res.json();
            showAlert(data.message, !data.success);
            if (data.success) {
                e.target.closest('form[data-form="rt"]').remove();
            }
        } catch (err) {
            showAlert('Tidak dapat terhubung ke server.', true);
        }
    }

    // --- Tambah RT baru (dinamis) ---
    if (e.target.matches('[data-add-rt]')) {
        const lingkunganId = e.target.dataset.addRt;
        const tpl = document.getElementById('tpl-rt-row');
        const clone = tpl.content.cloneNode(true);
        clone.querySelector('input[name="lingkungan_id"]').value = lingkunganId;

        const card = e.target.closest('[data-lingkungan-id]');
        card.querySelector('[data-rt-list]').appendChild(clone);
    }
});

// --- Tambah Lingkungan baru (dinamis) ---
document.getElementById('btn-add-lingkungan').addEventListener('click', () => {
    const tpl = document.getElementById('tpl-lingkungan-card');
    const clone = tpl.content.cloneNode(true);
    document.getElementById('lingkungan-list').appendChild(clone);
});
