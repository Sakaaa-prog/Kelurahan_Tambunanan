// Scrollspy: pindahkan garis bawah nav sesuai section yang sedang terlihat
const navLinks = document.querySelectorAll(".nav-link");
const sections = document.querySelectorAll("section[id]");

function setActiveNavLink(sectionId) {
  navLinks.forEach((link) => {
    const isActive = link.dataset.section === sectionId;
    link.classList.toggle("text-secondary-fixed", isActive);
    link.classList.toggle("font-bold", isActive);
    link.classList.toggle("border-secondary-fixed", isActive);
    link.classList.toggle("opacity-80", !isActive);
  });
}

if (sections.length && navLinks.length) {
  const spyObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveNavLink(entry.target.id);
        }
      });
    },
    { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
  );

  sections.forEach((section) => spyObserver.observe(section));
  setActiveNavLink("home"); // default saat halaman pertama dibuka
}

// Mobile hamburger menu toggle
const hamburgerBtn = document.getElementById("hamburger-btn");
const mobileMenu = document.getElementById("mobile-menu");

if (hamburgerBtn && mobileMenu) {
  hamburgerBtn.addEventListener("click", () => {
    const isOpen = mobileMenu.classList.toggle("flex");
    mobileMenu.classList.toggle("hidden");
    hamburgerBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");

    const bar1 = document.getElementById("bar1");
    const bar2 = document.getElementById("bar2");
    const bar3 = document.getElementById("bar3");
    bar1.classList.toggle("rotate-45");
    bar1.classList.toggle("translate-y-2");
    bar2.classList.toggle("opacity-0");
    bar3.classList.toggle("-rotate-45");
    bar3.classList.toggle("-translate-y-2");
  });

  // Close mobile menu after clicking a link
  mobileMenu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      mobileMenu.classList.add("hidden");
      mobileMenu.classList.remove("flex");
      hamburgerBtn.setAttribute("aria-expanded", "false");
    });
  });
}

// Header transparency scroll effect
window.addEventListener("scroll", () => {
  const header = document.querySelector("header");
  if (window.scrollY > 50) {
    header.classList.remove("bg-transparent");
    header.classList.add("bg-primary/95", "shadow-lg");
  } else {
    header.classList.add("bg-transparent");
    header.classList.remove("bg-primary/95", "shadow-lg");
  }
});

// Simple fade-in intersection observer
const observerOptions = {
  threshold: 0.1,
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("opacity-100", "translate-y-0");
      entry.target.classList.remove("opacity-0", "translate-y-10");
    }
  });
}, observerOptions);

document.querySelectorAll("section > div").forEach((el) => {
  el.classList.add("transition-all", "duration-1000", "opacity-0", "translate-y-10");
  observer.observe(el);
});
